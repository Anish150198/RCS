import pyodbc
import json
import os
import sys
import re
from z3 import sat
import z3
from query_parser import QueryParser
from config_util import fetch_schema_column_info, load_config, build_sqlserver_connstr
from mutant import generate_mutant_killing_data
from random import randint, uniform, choices

# Global PK counter for unique PK/FK values across all mutants and not-null rows
GLOBAL_PK_COUNTER = 1

def load_sql(filename):
    with open(filename, 'r') as f:
        return f.read().strip().rstrip(';')

def run_and_fetch(conn_str, sql):
    with pyodbc.connect(conn_str) as conn:
        cursor = conn.cursor()
        cursor.execute(sql)
        # fetch column names and rows
        columns = [desc[0] for desc in cursor.description]
        rows = cursor.fetchall()
        # Convert rows to tuples for easy comparison
        result = [tuple(row) for row in rows]
        # Sort for set-style comparison (order-invariant)
        def safe_tuple(x):
            return tuple("" if v is None else str(v) for v in x)  # Convert all to str for sorting
        result.sort(key=safe_tuple)
        return columns, result

def compare_query_results(cols1, res1, cols2, res2):
    if cols1 != cols2:
        print(" Column sets differ!")
        print("Original columns:", cols1)
        print("Mutant columns:  ", cols2)
        return False
    if res1 == res2:
        print(" Query results are equivalent.")
        return True
    else:
        print(" Query results differ!")
        print("Original result:")
        for row in res1:
            print(row)
        print("Mutant result:")
        for row in res2:
            print(row)
        return False


def pad_to_maxlen(seed: str, maxlen: int) -> str:
    """
    Pads the seed string with 'A's to reach maxlen.
    """
    if maxlen is None or maxlen <= 0:
        return seed
    s = seed
    while len(s) < maxlen:
        s += 'A'
    return s[:maxlen]


class Tee(object):
    def __init__(self, *files):
        self.files = files
    def write(self, obj):
        for f in self.files:
            f.write(obj)
            f.flush()
    def flush(self):
        for f in self.files:
            f.flush()

sys.stdout = Tee(sys.stdout, open('output.txt', 'w'))
sys.stderr = sys.stdout  # For errors too

def is_string_type(col_type):
    if not col_type:
        return False
    col_type = col_type.lower()
    return any(x in col_type for x in ['char', 'text', 'string', 'date', 'time'])

def is_float_type(col_type):
    if not col_type:
        return False
    col_type = col_type.lower()
    return any(x in col_type for x in ['float', 'real', 'double', 'decimal', 'numeric'])

def is_int_type(col_type):
    if not col_type:
        return False
    col_type = col_type.lower()
    return any(x in col_type for x in ['int', 'bigint', 'smallint', 'tinyint'])


def backpropagate_computed_assignments(assignment, projected_columns, schema_info=None):
    import re
    updates = {}
    for key, value in assignment.items():
        # Handle substring expressions: "substring(['table', 'col'],1,5)"
        m = re.match(r"substring\(\[?'?(\w+)'?,\s*'?(.*?)'?\],\s*(\d+),\s*(\d+)\)", key)
        if m:
            table, col, start, length = m.group(1), m.group(2), int(m.group(3)), int(m.group(4))
            # --- Determine the max allowed length for this column ---
            col_meta = schema_info.get(table, {}).get(col, {}) if schema_info else {}
            maxlen = int(col_meta.get('max_length', 20))
            if maxlen == -1:  # -1 means MAX in SQL Server, treat as 255
                maxlen = 255
            # Build a base string for the column (padded with 'A's as before)
            base_val = ['A'] * max(maxlen, start - 1 + len(str(value)))
            value_str = str(value)
            for i in range(len(value_str)):
                if start - 1 + i < len(base_val):
                    base_val[start - 1 + i] = value_str[i]
            outval = ''.join(base_val)[:maxlen]
            updates[f"{table}__{col}"] = outval
    assignment.update(updates)
    return assignment



class TestDataGenerator:
    def __init__(self, schema_info, assignment, conn_str, schema='dbo', projected_columns = None, constraints=None):
        """
        schema_info: {table: {col: {type, nullable}}}
        assignment: {'table__col': value, ...}
        conn_str: SQLServer ODBC connection string
        constraints: list of extracted constraints (from constraint_set.all())
        """
        self.schema_info = schema_info
        self.assignment = assignment
        self.conn_str = conn_str
        self.schema = schema
        self.projected_columns = projected_columns if projected_columns is not None else {}
        self.constraints = constraints if constraints is not None else []
        self.having_count_info = self._find_having_count_constraint(self.constraints)
        self.group_by_columns = self._find_group_by_columns(self.constraints)
        self.table_row_data = self._extract_table_rows()

    def _find_having_count_constraint(self, constraints):
        """
        Recursively search for a HAVING count constraint of the form count(*) >= N or count(col) >= N.
        Returns a dict: {N: int, col: column or None}
        """
        if isinstance(constraints, dict):
            c = constraints
            # Look for gte or eq or gt with left or right as aggregate/count
            if c.get("type") in ("gte", "eq", "gt"):
                left = c.get("left")
                right = c.get("right")
                # left: aggregate, right: N
                if (
                    isinstance(left, dict)
                    and left.get("type") == "aggregate"
                    and left.get("agg_func", "").upper() == "COUNT"
                ):
                    try:
                        N = int(right)
                    except Exception:
                        N = 1
                    return {"N": N, "col": left.get("column")}
                # right: aggregate, left: N
                if (
                    isinstance(right, dict)
                    and right.get("type") == "aggregate"
                    and right.get("agg_func", "").upper() == "COUNT"
                ):
                    try:
                        N = int(left)
                    except Exception:
                        N = 1
                    return {"N": N, "col": right.get("column")}
            # Recurse into children
            for v in c.values():
                res = self._find_having_count_constraint(v)
                if res:
                    return res
        elif isinstance(constraints, list):
            for c in constraints:
                res = self._find_having_count_constraint(c)
                if res:
                    return res
        return None

    def _find_group_by_columns(self, constraints):
        """
        Find all group_by columns in the constraints.
        Returns a list of [table, col] pairs.
        """
        group_cols = []
        if isinstance(constraints, dict):
            if constraints.get("type") == "group_by":
                group_cols.append(constraints.get("column"))
            for v in constraints.values():
                group_cols += self._find_group_by_columns(v)
        elif isinstance(constraints, list):
            for c in constraints:
                group_cols += self._find_group_by_columns(c)
        return group_cols

    def _extract_table_rows(self):
        table_rows = {}
        multi_val_cols = {}
        for key, value in self.assignment.items():
            if "__" in key:
                tbl, col = key.split("__", 1)
                if isinstance(value, list):
                    multi_val_cols[(tbl, col)] = value
        # --- HAVING count(*) >= N logic ---
        having_info = self.having_count_info
        group_by_cols = self.group_by_columns
        # Only apply if both HAVING and GROUP BY are present
        if having_info and group_by_cols:
            N = having_info["N"]
            group_cols = group_by_cols
            # For now, assume all group by columns are from the same table
            group_table = None
            if group_cols:
                group_table = group_cols[0][0]
            if group_table and group_table in self.schema_info:
                # Generate N rows per group for the group_table
                # Use projected columns for that table
                projected = set()
                if self.projected_columns and group_table in self.projected_columns:
                    projected = set(self.projected_columns[group_table])
                # Build a single group key (use default values for group by columns)
                group_key = {}
                for tbl, col in group_cols:
                    if tbl == group_table:
                        col_type = self.schema_info[group_table][col]["type"]
                        if is_string_type(col_type):
                            group_key[col] = pad_to_maxlen('A', self.schema_info[group_table][col].get("max_length", 0))
                        else:
                            group_key[col] = self._default_for_type(col_type)
                # Generate N rows with same group key, but unique PKs
                pk_col = None
                for col, meta in self.schema_info[group_table].items():
                    if meta.get("is_pk") or col.lower().endswith("_sk") or col.lower().endswith("_id"):
                        pk_col = col
                        break
                for i in range(N):
                    row = dict(group_key)
                    # Set PK to unique value
                    if pk_col:
                        row[pk_col] = i + 1
                    # Fill other projected columns
                    for col, meta in self.schema_info[group_table].items():
                        if col in row:
                            continue
                        key = f"{group_table}__{col}"
                        value_set = False
                        if key in self.assignment:
                            v = self._z3_val_to_python(self.assignment[key])
                            if is_string_type(meta.get("type", "")):
                                maxlen = meta.get("max_length", 0)
                                if maxlen > 0:
                                    v = str(v)[:maxlen]
                                else:
                                    v = str(v)
                            row[col] = v
                            value_set = True
                        if not value_set and col in projected:
                            col_type = meta.get("type", "int")
                            if is_string_type(col_type):
                                row[col] = pad_to_maxlen('A', meta.get("max_length", 0))
                            else:
                                row[col] = self._default_for_type(col_type)
                            value_set = True
                        if not value_set and not meta.get('nullable', True):
                            col_type = meta.get("type", "int")
                            if is_string_type(col_type):
                                row[col] = pad_to_maxlen('A', meta.get("max_length", 0))
                            else:
                                row[col] = self._default_for_type(col_type)
                    # Ensure all projected columns are set and not None
                    for proj_col in projected:
                        if proj_col not in row or row[proj_col] is None:
                            col_type = self.schema_info[group_table].get(proj_col, {}).get("type", "int")
                            if is_string_type(col_type):
                                row[proj_col] = pad_to_maxlen('A', self.schema_info[group_table].get(proj_col, {}).get("max_length", 0))
                            else:
                                row[proj_col] = self._default_for_type(col_type)
                    table_rows.setdefault(group_table, []).append(row)
                # Continue for other tables as normal
                for table, table_cols in self.schema_info.items():
                    if table == group_table:
                        continue
                    multi_cols = [col for (tbl, col) in multi_val_cols if tbl == table]
                    projected = set()
                    if self.projected_columns and table in self.projected_columns:
                        projected = set(self.projected_columns[table])
                    if multi_cols:
                        for idx, val in enumerate(multi_val_cols[(table, multi_cols[0])] ):
                            row = {}
                            row[multi_cols[0]] = val
                            for col, meta in table_cols.items():
                                if col == multi_cols[0]:
                                    continue
                                key = f"{table}__{col}"
                                value_set = False
                                if key in self.assignment:
                                    v = self._z3_val_to_python(self.assignment[key])
                                    if is_string_type(meta.get("type", "")):
                                        maxlen = meta.get("max_length", 0)
                                        if maxlen > 0:
                                            v = str(v)[:maxlen]
                                        else:
                                            v = str(v)
                                    row[col] = v
                                    value_set = True
                                if not value_set and col in projected:
                                    col_type = meta.get("type", "int")
                                    if is_string_type(col_type):
                                        row[col] = pad_to_maxlen('A', meta.get("max_length", 0))
                                    else:
                                        row[col] = self._default_for_type(col_type)
                                    value_set = True
                                if not value_set and not meta.get('nullable', True):
                                    col_type = meta.get("type", "int")
                                    if is_string_type(col_type):
                                        row[col] = pad_to_maxlen('A', meta.get("max_length", 0))
                                    else:
                                        row[col] = self._default_for_type(col_type)
                            for proj_col in projected:
                                if proj_col not in row or row[proj_col] is None:
                                    col_type = table_cols.get(proj_col, {}).get("type", "int")
                                    if is_string_type(col_type):
                                        row[proj_col] = pad_to_maxlen('A', table_cols.get(proj_col, {}).get("max_length", 0))
                                    else:
                                        row[proj_col] = self._default_for_type(col_type)
                            table_rows.setdefault(table, []).append(row)
                    else:
                        row = {}
                        for col, meta in table_cols.items():
                            key = f"{table}__{col}"
                            value_set = False
                            if key in self.assignment:
                                v = self._z3_val_to_python(self.assignment[key])
                                if is_string_type(meta.get("type", "")):
                                    maxlen = meta.get("max_length", 0)
                                    if maxlen > 0:
                                        v = str(v)[:maxlen]
                                    else:
                                        v = str(v)
                                row[col] = v
                                value_set = True
                            if not value_set and col in projected:
                                col_type = meta.get("type", "int")
                                if is_string_type(col_type):
                                    row[col] = pad_to_maxlen('A', meta.get("max_length", 0))
                                else:
                                    row[col] = self._default_for_type(col_type)
                                value_set = True
                            if not value_set and not meta.get('nullable', True):
                                col_type = meta.get("type", "int")
                                if is_string_type(col_type):
                                    row[col] = pad_to_maxlen('A', meta.get("max_length", 0))
                                else:
                                    row[col] = self._default_for_type(col_type)
                        if row:
                            if projected:
                                for proj_col in projected:
                                    if proj_col not in row or row[proj_col] is None:
                                        col_type = table_cols.get(proj_col, {}).get("type", "int")
                                        if is_string_type(col_type):
                                            row[proj_col] = pad_to_maxlen('A', table_cols.get(proj_col, {}).get("max_length", 0))
                                        else:
                                            row[proj_col] = self._default_for_type(col_type)
                            table_rows.setdefault(table, []).append(row)
                return table_rows
        # ...existing code (original _extract_table_rows) for when HAVING is not present...
        table_rows = {}
        multi_val_cols = {}
        for key, value in self.assignment.items():
            if "__" in key:
                tbl, col = key.split("__", 1)
                if isinstance(value, list):
                    multi_val_cols[(tbl, col)] = value
        for table, table_cols in self.schema_info.items():
            multi_cols = [col for (tbl, col) in multi_val_cols if tbl == table]
            projected = set()
            if self.projected_columns and table in self.projected_columns:
                projected = set(self.projected_columns[table])
            if multi_cols:
                for idx, val in enumerate(multi_val_cols[(table, multi_cols[0])]):
                    row = {}
                    row[multi_cols[0]] = val
                    for col, meta in table_cols.items():
                        if col == multi_cols[0]:
                            continue
                        key = f"{table}__{col}"
                        value_set = False
                        if key in self.assignment:
                            v = self._z3_val_to_python(self.assignment[key])
                            if is_string_type(meta.get("type", "")):
                                maxlen = meta.get("max_length", 0)
                                if maxlen > 0:
                                    v = str(v)[:maxlen]
                                else:
                                    v = str(v)
                            row[col] = v
                            value_set = True
                        if not value_set and col in projected:
                            col_type = meta.get("type", "int")
                            if is_string_type(col_type):
                                row[col] = pad_to_maxlen('A', meta.get("max_length", 0))
                            else:
                                row[col] = self._default_for_type(col_type)
                            value_set = True
                        if not value_set and not meta.get('nullable', True):
                            col_type = meta.get("type", "int")
                            if is_string_type(col_type):
                                row[col] = pad_to_maxlen('A', meta.get("max_length", 0))
                            else:
                                row[col] = self._default_for_type(col_type)
                    # Ensure all projected columns are set and not None
                    for proj_col in projected:
                        if proj_col not in row or row[proj_col] is None:
                            col_type = table_cols.get(proj_col, {}).get("type", "int")
                            if is_string_type(col_type):
                                row[proj_col] = pad_to_maxlen('A', table_cols.get(proj_col, {}).get("max_length", 0))
                            else:
                                row[proj_col] = self._default_for_type(col_type)
                    table_rows.setdefault(table, []).append(row)
            else:
                row = {}
                for col, meta in table_cols.items():
                    key = f"{table}__{col}"
                    value_set = False
                    if key in self.assignment:
                        v = self._z3_val_to_python(self.assignment[key])
                        # Do NOT pad predicate/assignment columns, only truncate
                        if is_string_type(meta.get("type", "")):
                            maxlen = meta.get("max_length", 0)
                            if maxlen > 0:
                                v = str(v)[:maxlen]
                            else:
                                v = str(v)
                        row[col] = v
                        value_set = True
                    if not value_set and col in projected:
                        col_type = meta.get("type", "int")
                        if is_string_type(col_type):
                            row[col] = pad_to_maxlen('A', meta.get("max_length", 0))
                        else:
                            row[col] = self._default_for_type(col_type)
                        value_set = True
                    if not value_set and not meta.get('nullable', True):
                        col_type = meta.get("type", "int")
                        if is_string_type(col_type):
                            row[col] = pad_to_maxlen('A', meta.get("max_length", 0))
                        else:
                            row[col] = self._default_for_type(col_type)
                if row:
                    if projected:
                        for proj_col in projected:
                            if proj_col not in row or row[proj_col] is None:
                                col_type = table_cols.get(proj_col, {}).get("type", "int")
                                if is_string_type(col_type):
                                    row[proj_col] = pad_to_maxlen('A', table_cols.get(proj_col, {}).get("max_length", 0))
                                else:
                                    row[proj_col] = self._default_for_type(col_type)
                    table_rows.setdefault(table, []).append(row)
        # Ensure at least one row per table, using assignment/defaults
        global GLOBAL_PK_COUNTER
        for table, table_cols in self.schema_info.items():
            if table not in table_rows or not table_rows[table]:
                row = {}
                pk_col = None
                # Find PK column for this table
                for col, meta in table_cols.items():
                    if meta.get('is_pk') or col.lower().endswith('_sk') or col.lower().endswith('_id'):
                        pk_col = col
                        break
                for col, meta in table_cols.items():
                    key = f"{table}__{col}"
                    if key in self.assignment:
                        v = self._z3_val_to_python(self.assignment[key])
                        if is_string_type(meta.get("type", "")):
                            maxlen = meta.get("max_length", 0)
                            if maxlen > 0:
                                v = str(v)[:maxlen]
                            else:
                                v = str(v)
                        row[col] = v
                    elif not meta.get('nullable', True) or meta.get('is_pk'):
                        row[col] = self._default_for_type(meta.get('type', 'int'))
                # Set PK to unique value
                if pk_col:
                    row[pk_col] = GLOBAL_PK_COUNTER
                # Set FKs to match PKs in parent tables if possible
                for col, meta in table_cols.items():
                    if meta.get('is_fk') and pk_col:
                        row[col] = GLOBAL_PK_COUNTER
                if row:
                    print(f"[INFO] Ensuring at least one row for table {table}: {row}")
                    table_rows.setdefault(table, []).append(row)
                    GLOBAL_PK_COUNTER += 1
        return table_rows

    def _default_for_type(self, col_type):
        # Moved default logic here for reuse
        if "char" in col_type or "text" in col_type or "string" in col_type:
            return 'A'
        elif "int" in col_type:
            return 1
        elif "decimal" in col_type or "real" in col_type or "float" in col_type:
            return 1.0
        else:
            return 1


    def _sql_format_value(self, val, col_type):
        if val is None:
            return 'NULL'
        if is_string_type(col_type):
            val = str(val)
            # Escape single quotes for SQL
            val = val.replace("'", "''")
            return f"'{val}'"
        elif is_float_type(col_type):
            try:
                return str(float(val))
            except Exception:
                print(f"[WARN] Invalid float value for column, using 0.0 instead: {val}")
                return '0.0'
        elif is_int_type(col_type):
            try:
                return str(int(val))
            except Exception:
                print(f"[WARN] Invalid int value for column, using 1 instead: {val}")
                return '1'
        else:
            val = str(val)
            val = val.replace("'", "''")
            return f"'{val}'"

    def generate_insert_statements(self):
        insert_stmts = {}
        for table, rows in self.table_row_data.items():
            table_cols = self.schema_info[table]
            stmts = []
            for row in rows:
                cols, vals = [], []
                for col, val in row.items():
                    col_type = table_cols.get(col, {}).get("type", "int")
                    py_val = self._z3_val_to_python(val)
                    vals.append(self._sql_format_value(py_val, col_type))
                    cols.append(col)
                stmt = f"INSERT INTO {self.schema}.{table} ({', '.join(cols)}) VALUES ({', '.join(vals)});"
                stmts.append(stmt)
            insert_stmts[table] = stmts
        return insert_stmts

    def dump_sql(self, out_file='generated_test_data.sql'):
        stmts = self.generate_insert_statements()
        with open(out_file, 'w') as f:
            for table in stmts:
                for stmt in stmts[table]:
                    f.write(stmt + "\n")
        print(f"SQL statements written to {out_file}")


    def insert_to_db(self):
        """
        Actually inserts the generated data into the database.
        """
        print("\n[DEBUG] Starting database insertion")
        stmts = self.generate_insert_statements()
        print(f"[DEBUG] Generated {sum(len(s) for s in stmts.values())} total INSERT statements")
        with pyodbc.connect(self.conn_str) as conn:
            cursor = conn.cursor()
            for table, stmt_list in stmts.items():
                print(f"\n[DEBUG] Processing table: {table}")
                print(f"[DEBUG] Number of statements: {len(stmt_list)}")
                for i, stmt in enumerate(stmt_list):
                    # Print the row being inserted for traceability
                    if i < len(self.table_row_data.get(table, [])):
                        print(f"[INFO] Inserting row into {table}: {self.table_row_data[table][i]}")
                    print(f"\n[DEBUG] Executing: {stmt}")
                    try:
                        cursor.execute(stmt)
                        print("[DEBUG] Statement executed successfully")
                    except Exception as e:
                        print(f"[ERROR] Failed to insert into {table}: {e}")
                        print(f"[ERROR] Failed statement: {stmt}")
                        raise
                conn.commit()
                print(f"[DEBUG] Committed all inserts for table {table}")
        print("[DEBUG] All data inserted successfully")

    def add_mutant_killing_records_to_tables(self, table_data, query_file='query.sql'):
        """
        Calls mutant data generator and adds the mutant-killing records to the table_data dict.
        Does not change the existing not-null record insertion logic.
        """
        mutant_records = generate_mutant_killing_data(query_file)
        for table, records in mutant_records.items():
            if table not in table_data:
                table_data[table] = []
            # Add mutant-killing records, but do not remove or alter existing logic
            table_data[table].extend(records)
        return table_data

    def _z3_val_to_python(self, val):
        # IntNumRef: use as_long() only if truly integer
        if hasattr(val, "is_int_value") and val.is_int_value():
            return val.as_long()
        # RationalNumRef: use as_decimal or as_fraction
        if hasattr(val, "is_rational_value") and val.is_rational_value():
            try:
                # Try to get as float if possible
                return float(val.as_decimal(10))
            except Exception:
                try:
                    return float(val.as_fraction())
                except Exception:
                    return str(val.as_fraction())
        # RealNumRef: use as_decimal or as_fraction
        if hasattr(val, "as_decimal"):
            try:
                return float(val.as_decimal(10))
            except Exception:
                return str(val.as_decimal(10))
        # StringVal: use as_string()
        if hasattr(val, "as_string"):
            return val.as_string()
        # If Z3 value is a Z3 value object, get its string
        if hasattr(val, 'sexpr'):
            return str(val)
        # Else, try regular conversion (could be int, str, etc.)
        return val

    def insert_row(self, row_assignment, table=None):
        """
        Insert a single row into the database using the assignment dict.
        If table is not specified, infer from keys (assumes all keys are like 'table__col').
        """
        if table is None:
            tables = set(k.split('__')[0] for k in row_assignment.keys())
            if len(tables) == 1:
                table = tables.pop()
            else:
                print("[ERROR] Ambiguous table for row insertion.")
                return
        cols = []
        vals = []
        for k, v in row_assignment.items():
            if k.startswith(table + '__'):
                col = k[len(table) + 2:]
                cols.append(col)
                vals.append(v)
        if not cols:
            print(f"[ERROR] No columns found for table {table} in row_assignment: {row_assignment}")
            return
        col_str = ', '.join(cols)
        val_str = ', '.join([f"'{v}'" if isinstance(v, str) else str(v) for v in vals])
        sql = f"INSERT INTO {table} ({col_str}) VALUES ({val_str});"
        print(f"[DEBUG] Executing mutant insert: {sql}")
        try:
            import pyodbc
            conn = pyodbc.connect(self.conn_str)
            cursor = conn.cursor()
            cursor.execute(sql)
            conn.commit()
            cursor.close()
            conn.close()
        except Exception as e:
            print(f"[ERROR] Failed to insert mutant row: {e}")


def build_constraint_driven_table_data(schema_info, constraint_set, current_table_data=None):
    """
    Builds a dictionary {table: [row_dict, ...]} where each row dict has all not null columns, PKs, FKs, and constraint-driven values.
    Does not interfere with current not-null record logic.
    """
    import copy
    table_data = current_table_data.copy() if current_table_data else {tbl: [] for tbl in schema_info}
    # Helper: get not null columns for a table
    def not_null_cols(table):
        return [col for col, meta in schema_info[table].items() if not meta.get('nullable', True)]
    # Helper: get PK columns
    def pk_cols(table):
        return [col for col, meta in schema_info[table].items() if meta.get('is_pk') or col.lower().endswith('_sk') or col.lower().endswith('_id')]
    # Helper: get FK columns
    def fk_cols(table):
        return [col for col, meta in schema_info[table].items() if meta.get('is_fk')]
    # Helper: default value for type
    def default_for_type(col_type):
        if is_string_type(col_type): return 'A'
        if is_float_type(col_type): return 1.0
        if is_int_type(col_type): return 1
        return None
    # Helper: fill all not null columns
    def fill_not_null(table, base=None):
        row = base.copy() if base else {}
        for col in not_null_cols(table):
            if col not in row:
                row[col] = default_for_type(schema_info[table][col]['type'])
        return row
    # --- Process constraints ---
    for constraint in constraint_set:
        ctype = constraint.get('type')
        if ctype == 'in':
            table, col = constraint['column'] if isinstance(constraint['column'], list) else (None, constraint['column'])
            for v in constraint['values']:
                base = fill_not_null(table)
                base[col] = v
                table_data[table].append(base)
        elif ctype == 'between':
            table, col = constraint['column'] if isinstance(constraint['column'], list) else (None, constraint['column'])
            low, high = constraint['low'], constraint['high']
            for v in [low+1, low-1, high+1]:
                base = fill_not_null(table)
                base[col] = v
                table_data[table].append(base)
        elif ctype == 'or':
            for side in ['left', 'right']:
                for subc in constraint[side]:
                    table_data = build_constraint_driven_table_data(schema_info, [subc], table_data)
        elif ctype in ('gt', 'gte', 'lt', 'lte', 'eq', 'neq'):
            table, col = constraint['left'] if isinstance(constraint['left'], list) else (None, constraint['left'])
            val = constraint['right']
            if table and isinstance(val, (int, float)):
                for v in ([val-1, val, val+1] if ctype in ('gt', 'gte', 'lt', 'lte') else [val, val+1]):
                    base = fill_not_null(table)
                    base[col] = v
                    table_data[table].append(base)
        elif ctype == 'like':
            table, col = constraint['column'] if isinstance(constraint['column'], list) else (None, constraint['column'])
            pattern = constraint['pattern']
            for v in [pattern.replace('%', 'X').replace('_', 'a'), 'X' + pattern.strip('%').replace('_', 'a') + 'X']:
                base = fill_not_null(table)
                base[col] = v
                table_data[table].append(base)
        elif ctype == 'equality':
            left = constraint['left']
            right = constraint['right']
            if isinstance(left, list) and isinstance(right, list):
                t1, c1 = left
                t2, c2 = right
                val = 1 + len(table_data[t1])
                base1 = fill_not_null(t1)
                base2 = fill_not_null(t2)
                base1[c1] = val
                base2[c2] = val
                table_data[t1].append(base1)
                table_data[t2].append(base2)
        elif ctype == 'substring':
            table, col = constraint['column'] if isinstance(constraint['column'], list) else (None, constraint['column'])
            substr_val = constraint.get('value', 'A')
            base = fill_not_null(table)
            base[col] = substr_val
            table_data[table].append(base)
        # Add more clause types as needed
    # Ensure all rows have all not null columns
    for table, rows in table_data.items():
        for i, row in enumerate(rows):
            rows[i] = fill_not_null(table, row)
    return table_data

def get_default_for_type(col_type):
    """Helper to get default values for column types"""
    if is_string_type(col_type): 
        val = 'A'
        print(f"[DEBUG] Default string value: {val} for type {col_type}")
        return val
    if is_float_type(col_type): 
        val = 1.0
        print(f"[DEBUG] Default float value: {val} for type {col_type}")
        return val
    if is_int_type(col_type): 
        val = 1
        print(f"[DEBUG] Default int value: {val} for type {col_type}")
        return val
    print(f"[DEBUG] No default value for type {col_type}")
    return None

def process_constraint_recursively(table_data, constraint, schema_info, pkfk_list, projected_columns=None):
    """
    Recursively processes a constraint, updating table_data with new records as needed.
    """
    import copy
    ctype = constraint.get('type')
    print(f"\n[DEBUG] Processing constraint type: {ctype}")
    print(f"[DEBUG] Constraint details: {constraint}")

    # IN clause handling
    if ctype == 'in':
        col_info = constraint.get('column')
        if isinstance(col_info, list) and len(col_info) == 2:
            table, col = col_info
        else:
            table, col = None, col_info
            
        if table is None:
            print(f"[WARN] Skipping IN constraint - no table specified: {constraint}")
            return
            
        print(f"[DEBUG] Processing IN values for {table}.{col}")
        values = constraint.get('values', [])
        for val in values:
            base = {}
            # Add all not-null columns
            for pcol, meta in schema_info[table].items():
                if not meta.get('nullable', True):
                    base[pcol] = get_default_for_type(meta['type'])
            base[col] = val
            print(f"[DEBUG] Adding record to {table}: {base}")
            table_data[table].append(base)

    # OR clause handling
    elif ctype == 'or':
        print("[DEBUG] Processing OR clause")
        for side in ['left', 'right']:
            if side in constraint:
                subclauses = constraint[side] if isinstance(constraint[side], list) else [constraint[side]]
                for subclause in subclauses:
                    process_constraint_recursively(table_data, subclause, schema_info, pkfk_list, projected_columns)

    # Join/equality handling
    elif ctype == 'equality':
        print("[DEBUG] Processing equality/join constraint")
        left = constraint.get('left')
        right = constraint.get('right')
        if isinstance(left, list) and isinstance(right, list):
            t1, c1 = left
            t2, c2 = right
            val = 1
            # Create records in both tables with matching values
            base1 = {c1: val}
            base2 = {c2: val}
            
            # Add not-null columns
            for pcol, meta in schema_info[t1].items():
                if not meta.get('nullable', True) and pcol != c1:
                    base1[pcol] = get_default_for_type(meta['type'])
            for pcol, meta in schema_info[t2].items():
                if not meta.get('nullable', True) and pcol != c2:
                    base2[pcol] = get_default_for_type(meta['type'])
                    
            print(f"[DEBUG] Adding join records: {t1}: {base1}, {t2}: {base2}")
            table_data[t1].append(base1)
            table_data[t2].append(base2)

    # Substring handling
    elif ctype == 'substring':
        print("[DEBUG] Processing substring constraint")
        col_info = constraint.get('column')
        if isinstance(col_info, list) and len(col_info) == 2:
            table, col = col_info
            values = constraint.get('values', [constraint.get('value', 'A')])
            for val in values:
                base = {}
                for pcol, meta in schema_info[table].items():
                    if not meta.get('nullable', True):
                        base[pcol] = get_default_for_type(meta['type'])
                base[col] = val
                print(f"[DEBUG] Adding substring record: {table}: {base}")
                table_data[table].append(base)

    return table_data

def maintain_foreign_keys(table_data, pkfk_relations, schema_info):
    """
    Ensures foreign key relationships are maintained across tables.
    """
    print("\n[DEBUG] Maintaining foreign key relationships")
    
    # First pass: collect all primary key values
    pk_values = {}  # {(table, column): set(values)}
    for table, rows in table_data.items():
        for row in rows:
            for col in row:
                pk_values[(table, col)] = pk_values.get((table, col), set()) | {row[col]}
    
    print(f"[DEBUG] Collected PK values: {pk_values}")
    
    # Second pass: ensure foreign keys exist in parent tables
    for rel in pkfk_relations:
        try:
            print(f"[DEBUG] Processing relation: {rel}")
            # Extract table and column names from the relation
            pk_table = rel.get('parent_table') or rel.get('pk_table')
            pk_col = rel.get('parent_column') or rel.get('pk_column')
            fk_table = rel.get('child_table') or rel.get('fk_table')
            fk_col = rel.get('child_column') or rel.get('fk_column')
            
            if not all([pk_table, pk_col, fk_table, fk_col]):
                print(f"[WARN] Incomplete relation info: {rel}")
                continue
                
            print(f"[DEBUG] Checking {fk_table}.{fk_col} -> {pk_table}.{pk_col}")
            
            # Get all FK values used
            fk_values = set()
            if fk_table in table_data:
                for row in table_data[fk_table]:
                    if fk_col in row:
                        fk_values.add(row[fk_col])
            
            # Ensure parent records exist for all FK values
            if pk_table not in table_data:
                table_data[pk_table] = []
            
            existing_pk_values = {row[pk_col] for row in table_data[pk_table] if pk_col in row}
            missing_values = fk_values - existing_pk_values
            
            print(f"[DEBUG] FK values: {fk_values}")
            print(f"[DEBUG] Existing PK values: {existing_pk_values}")
            print(f"[DEBUG] Missing values: {missing_values}")
            
            # Add missing parent records
            for val in missing_values:
                new_row = {}
                # Fill required columns
                for col, meta in schema_info[pk_table].items():
                    if not meta.get('nullable', True):
                        new_row[col] = get_default_for_type(meta['type'])
                new_row[pk_col] = val
                table_data[pk_table].append(new_row)
                print(f"[DEBUG] Added parent record in {pk_table}: {new_row}")
                
        except Exception as e:
            print(f"[ERROR] Error processing relation {rel}: {str(e)}")
            continue

    return table_data

def build_full_test_data_dict(schema_info, constraints, pkfk_list, projected_columns=None):
    """
    Builds a full test data dictionary for all tables.
    """
    print("\n[DEBUG] Starting build_full_test_data_dict")
    print(f"[DEBUG] Schema tables: {list(schema_info.keys())}")
    print(f"[DEBUG] Number of constraints: {len(constraints)}")
    print(f"[DEBUG] Number of PKFK relations: {len(pkfk_list)}")
    
    table_data = {tbl: [] for tbl in schema_info}
    
    # Process constraints first
    for constraint in constraints:
        process_constraint_recursively(table_data, constraint, schema_info, pkfk_list, projected_columns)
        
    # Maintain foreign key relationships
    table_data = maintain_foreign_keys(table_data, pkfk_list, schema_info)
    
    # Ensure all required columns are present
    for table in schema_info:
        if table not in table_data:
            table_data[table] = []
        if not table_data[table]:
            # Add at least one row for tables with no data
            row = {}
            for col, meta in schema_info[table].items():
                if not meta.get('nullable', True):
                    row[col] = get_default_for_type(meta['type'])
            if row:
                table_data[table].append(row)
                
    return table_data
# ...existing code...

def ensure_minimal_rows_for_having_aggregate(table_name, table_rows, schema_info, constraints):
    """
    Generalized: Ensures minimal rows for any table with HAVING/aggregate/subquery constraints.
    - If a HAVING AVG(col) > k * (subquery AVG) is detected, generates two rows with values to satisfy it.
    - Otherwise, returns table_rows unchanged.
    """
    # Detect HAVING AVG(col) > k * (subquery aggregate)
    found = False
    target_col = None
    multiplier = None
    subquery_col = None
    for c in constraints:
        if isinstance(c, dict) and c.get('type') == 'gt':
            left = c.get('left')
            right = c.get('right')
            # left: aggregate, right: k * (subquery aggregate)
            if (
                isinstance(left, dict) and left.get('type') == 'aggregate' and left.get('agg_func', '').upper() == 'AVG'
                and isinstance(right, dict) and right.get('type') == 'mul'
            ):
                # right: mul node
                k = right.get('left')
                subq = right.get('right')
                if (
                    isinstance(subq, dict) and subq.get('type') == 'aggregate' and subq.get('agg_func', '').upper() == 'AVG'
                ):
                    found = True
                    target_col = left.get('column')
                    multiplier = float(k) if isinstance(k, (int, float, str)) else 0.9
                    subquery_col = subq.get('column')
    if not found or not target_col:
        return table_rows
    # Ensure at least two rows with correct values
    col = target_col[-1] if isinstance(target_col, list) else target_col
    # Find a not-null column for subquery (if any)
    not_null_col = None
    for c in schema_info[table_name]:
        if not schema_info[table_name][c].get('nullable', True):
            not_null_col = c
            break
    row1 = {col: 100}
    row2 = {col: 200}
    # For subquery AVG, ensure one row has not_null_col set (if required)
    if not_null_col:
        row1[not_null_col] = 10
        row2[not_null_col] = None
    # Fill PKs and other not-null columns
    for row in [row1, row2]:
        for c, meta in schema_info[table_name].items():
            if c not in row and (not meta.get('nullable', True) or meta.get('is_pk')):
                t = meta.get('type', '').lower()
                if any(x in t for x in ['char', 'text', 'string', 'date', 'time']):
                    row[c] = 'A'
                elif any(x in t for x in ['float', 'real', 'decimal']):
                    row[c] = 1.0
                else:
                    row[c] = 1
    # Add if not already present
    if not table_rows:
        table_rows.extend([row1, row2])
    elif len(table_rows) == 1:
        table_rows.append(row2)
    return table_rows


def has_having_or_aggregate_constraint(constraints):
    """
    Recursively checks if any constraint is a HAVING/aggregate/subquery constraint.
    Returns True if found, else False.
    """
    if isinstance(constraints, dict):
        if constraints.get('type') in ('aggregate', 'having', 'gt', 'lt', 'gte', 'lte'):
            # Look for aggregate in left/right or nested
            left = constraints.get('left')
            right = constraints.get('right')
            if (isinstance(left, dict) and left.get('type') == 'aggregate') or \
               (isinstance(right, dict) and right.get('type') == 'aggregate'):
                return True
        for v in constraints.values():
            if has_having_or_aggregate_constraint(v):
                return True
    elif isinstance(constraints, list):
        for c in constraints:
            if has_having_or_aggregate_constraint(c):
                return True
    return False




# --- Helper: Extract all IN clauses from constraints ---
def extract_in_clauses(constraints):
    """
    Recursively extract all (column, values) pairs for IN clauses from the constraints tree.
    Returns a list of (column, values) tuples.
    """
    in_clauses = []
    if isinstance(constraints, dict):
        if constraints.get("type") == "in":
            col = constraints.get("column")
            vals = constraints.get("values")
            if col is not None and vals is not None:
                in_clauses.append((col, vals))
        for v in constraints.values():
            in_clauses.extend(extract_in_clauses(v))
    elif isinstance(constraints, list):
        for c in constraints:
            in_clauses.extend(extract_in_clauses(c))
    return in_clauses


def set_constraint_at_path(constraints, path, new_constraint):
    """
    Recursively set a constraint at the given path in the constraint tree.
    Returns a new constraints tree with the mutation applied.
    """
    if not path:
        return new_constraint
    head, *tail = path
    if isinstance(constraints, dict):
        new_dict = dict(constraints)
        new_dict[head] = set_constraint_at_path(constraints[head], tail, new_constraint)
        return new_dict
    elif isinstance(constraints, list):
        new_list = list(constraints)
        new_list[head] = set_constraint_at_path(constraints[head], tail, new_constraint)
        return new_list
    else:
        return constraints

def split_assignment_by_table(assignment):
    """
    Given a flat assignment dict (e.g., item__i_item_sk, customer__c_customer_sk, ...),
    return a dict {table: {col: val, ...}} for each table.
    """
    table_rows = {}
    for k, v in assignment.items():
        if '__' in k:
            table, col = k.split('__', 1)
            if table not in table_rows:
                table_rows[table] = {}
            table_rows[table][col] = v
    return table_rows

def generate_and_insert_record(constraints, schema_info, conn_str, cfg, projected_columns, alias_to_table):
    global GLOBAL_PK_COUNTER
    z3_checker = Z3ConstraintChecker(constraints, schema_info, alias_to_table=alias_to_table)
    result, solver, z3_vars = z3_checker.check_satisfiability()
    if result == "sat" or result == sat:
        assignment = z3_checker.get_minimal_assignment()
        assignment = backpropagate_computed_assignments(assignment, projected_columns, schema_info)
        # Set all PK/FK columns to GLOBAL_PK_COUNTER
        for k in assignment:
            if k.endswith('_sk') or k.endswith('_id') or k.endswith('_number'):
                assignment[k] = GLOBAL_PK_COUNTER
        # Split assignment by table and insert each row
        table_rows = split_assignment_by_table(assignment)
        for table, row in table_rows.items():
            generator_mut = TestDataGenerator(schema_info, assignment, conn_str, schema=cfg['schema'], projected_columns=projected_columns)
            generator_mut.insert_row(row, table=table)
        GLOBAL_PK_COUNTER += 1

def try_parse_number(val):
    if isinstance(val, (int, float)):
        return val
    if isinstance(val, str):
        try:
            if '.' in val:
                return float(val)
            else:
                return int(val)
        except Exception:
            return None
    return None

# ------------- Main: Example Usage ------------------
if __name__ == "__main__":
    from z3_constraint_checker import ast_to_python
    from constraint_extractor import ConstraintExtractor
    from query_parser import QueryParser
    from config_util import load_config, build_sqlserver_connstr, fetch_schema_column_info, load_pkfk_csv_custom

    parser = QueryParser(sql_file="query.sql")
    qt_root = parser.build_query_tree()
    alias_to_table = parser.get_alias_to_table() if hasattr(parser, 'get_alias_to_table') else {}
    cfg = load_config("config.ini")
    conn_str = build_sqlserver_connstr(cfg)
    schema_info = fetch_schema_column_info(conn_str, db_schema=cfg['schema'])
    pkfk_list = load_pkfk_csv_custom(cfg['pkfk_path'])

    extractor = ConstraintExtractor(qt_root, schema_info, pkfk_list, alias_to_table)
    constraint_set = extractor.extract_constraints()
    projected_columns = extractor.get_projected_columns()

    from z3_constraint_checker import Z3ConstraintChecker
    cleaned_constraints = ast_to_python(constraint_set.all())
    print("All constraints:")
    for c in cleaned_constraints:
        print(json.dumps(c, indent=2))

    # --- FIX: Check for HAVING/aggregate constraints BEFORE Z3 ---
    # --- DEBUG: Show constraints and detection result before HAVING/aggregate check ---
    print("DEBUG: cleaned_constraints for HAVING/aggregate check:", json.dumps(cleaned_constraints, indent=2))
    print("DEBUG: has_having_or_aggregate_constraint:", has_having_or_aggregate_constraint(cleaned_constraints))

    if has_having_or_aggregate_constraint(cleaned_constraints):
        print("[INFO] HAVING/aggregate constraint detected. Using minimal row generator.")
        generator = TestDataGenerator(schema_info, { }, conn_str, schema=cfg['schema'], projected_columns = projected_columns)
        for tbl in generator.table_row_data:
            generator.table_row_data[tbl] = ensure_minimal_rows_for_having_aggregate(tbl, generator.table_row_data[tbl], schema_info, cleaned_constraints)
        # Debug print: show generated rows for all tables
        print("[DEBUG] Generated minimal table_row_data:")
        for tbl, rows in generator.table_row_data.items():
            print(f"Table {tbl}: {len(rows)} rows")
            for row in rows:
                print(row)
    else:
        z3_checker = Z3ConstraintChecker(cleaned_constraints, schema_info, alias_to_table = alias_to_table)
        result, solver, z3_vars = z3_checker.check_satisfiability()
        if result != "sat" and result != sat:
            print("Z3 UNSAT. Here’s the current assignment/model and variable list for debugging:")
            print("Z3 variables:", z3_vars)
            try:
                print("Model:", solver.model())
            except Exception:
                pass
            print("[INFO] Z3 UNSAT. Falling back to minimal row generator.")
            generator = TestDataGenerator(schema_info, { }, conn_str, schema=cfg['schema'], projected_columns = projected_columns)
            for tbl in generator.table_row_data:
                generator.table_row_data[tbl] = ensure_minimal_rows_for_having_aggregate(tbl, generator.table_row_data[tbl], schema_info, cleaned_constraints)
            print("[DEBUG] Generated minimal table_row_data:")
            for tbl, rows in generator.table_row_data.items():
                print(f"Table {tbl}: {len(rows)} rows")
                for row in rows:
                    print(row)
        else:
            print("[INFO] No HAVING/aggregate constraint. Using Z3 assignment.")
            assignment = z3_checker.get_minimal_assignment()
            assignment = backpropagate_computed_assignments(assignment, projected_columns, schema_info)
            generator = TestDataGenerator(schema_info, assignment, conn_str, schema=cfg['schema'], projected_columns = projected_columns)
    generator.dump_sql('generated_test_data.sql')
    print("[DEBUG] table_row_data before insert_to_db:")
    for tbl, rows in generator.table_row_data.items():
        print(f"Table {tbl}: {len(rows)} rows")
        for row in rows:
            print(row)
    generator.insert_to_db()

    # --- Print the minimal assignment after not-null scenario ---
    if hasattr(generator, 'assignment'):
        print("\n[DEBUG] Minimal assignment after not-null scenario:")
        for k, v in generator.assignment.items():
            print(f"  {k}: {v}")


# --- 2. Generate mutant-killing datasets (to be implemented next) ---
# Placeholder for mutant-killing logic, as per paper Section 5.2, Listing 8, A.3, A.4

# --- Mutant-Killing Dataset Generation (per XData paper Section 5.2, Listings 8, A.3, A.4) ---



    # --- After not-null/minimal insert, generate mutant-killing datasets for all IN clauses using minimal assignment as template ---
    for in_column, in_values in extract_in_clauses(cleaned_constraints):
        # Convert column to string key if it's a list
        if isinstance(in_column, list):
            in_column_key = '__'.join(in_column)
        else:
            in_column_key = in_column
        print(f"\n[INFO] Generating mutant-killing datasets for IN clause on {in_column_key}...")
        for val in in_values:
            mutant_assignment = dict(generator.assignment)  # Copy minimal assignment
            mutant_assignment[in_column_key] = val
            mutant_assignment = backpropagate_computed_assignments(mutant_assignment, projected_columns, schema_info)
            print(f"[DEBUG] Mutant assignment for {in_column_key} = {val}: {mutant_assignment}")
            generator_mut = TestDataGenerator(schema_info, mutant_assignment, conn_str, schema=cfg['schema'], projected_columns=projected_columns)
            print("[DEBUG] table_row_data before insert_to_db (mutant):")
            for tbl, rows in generator_mut.table_row_data.items():
                print(f"Table {tbl}: {len(rows)} rows")
                for row in rows:
                    print(row)
            generator_mut.insert_to_db()

    # --- Mutant-killing for OR conditions ---
    def extract_or_clauses(cleaned_constraints):
        or_clauses = []
        if isinstance(cleaned_constraints, dict):
            if cleaned_constraints.get("type") == "or":
                or_clauses.append((cleaned_constraints.get("left"), cleaned_constraints.get("right")))
            for v in cleaned_constraints.values():
                or_clauses.extend(extract_or_clauses(v))
        elif isinstance(cleaned_constraints, list):
            for c in cleaned_constraints:
                or_clauses.extend(extract_or_clauses(c))
        return or_clauses

    for left, right in extract_or_clauses(cleaned_constraints):
        for branch in [left, right]:
            print(f"\n[INFO] Generating mutant-killing dataset for OR branch: {branch}")
            # If you have a mutant_assignment for this branch:
            # assignment = ... (build from branch)
            # assignment = backpropagate_computed_assignments(assignment, projected_columns, schema_info)
            # generator_mut = TestDataGenerator(schema_info, assignment, conn_str, schema=cfg['schema'], projected_columns=projected_columns)
            # print("[DEBUG] table_row_data before insert_to_db (OR mutant):")
            # for tbl, rows in generator_mut.table_row_data.items():
            #     print(f"Table {tbl}: {len(rows)} rows")
            #     for row in rows:
            #         print(row)
            # generator_mut.insert_to_db()
    # --- Mutant-killing for operator mutants ---
    print("\n[INFO] Generating operator mutant-killing datasets...")
    for op_constraint in cleaned_constraints:
        if isinstance(op_constraint, dict) and op_constraint.get('type') in ('gt', 'lt', 'gte', 'lte', 'eq', 'neq'):
            # For each operator constraint, generate mutants by flipping the operator or value
            original_op = op_constraint.get('type')
            flipped_op = {
                'gt': 'lt',
                'lt': 'gt',
                'gte': 'lte',
                'lte': 'gte',
                'eq': 'neq',
                'neq': 'eq'
            }.get(original_op)
            
            if flipped_op:
                # Clone the constraint and modify the operator
                mutant_constraint = dict(op_constraint)
                mutant_constraint['type'] = flipped_op
                
                # For inequality flips (gt/lt/gte/lte), also flip the value side
                if original_op in ('gt', 'lt', 'gte', 'lte'):
                    mutant_constraint['left'], mutant_constraint['right'] = mutant_constraint['right'], mutant_constraint['left']
                
                # Print the mutant constraint for debugging
                print(f"[DEBUG] Generated mutant constraint: {mutant_constraint}")
                
                # --- TODO: Map mutant_constraint back to table data mutation ---
                # For now, just a placeholder print
                print(f"[INFO] Mutant constraint (to be implemented): {mutant_constraint}")
    # --- Generalized mutation for numeric columns in operator constraints ---
    def is_numeric_type(col_type):
        if not col_type:
            return False
        col_type = col_type.lower()
        return any(x in col_type for x in ['int', 'bigint', 'smallint', 'tinyint', 'float', 'real', 'double', 'decimal', 'numeric'])

    print("\n[INFO] (TOP-LEVEL) Generating generalized operator mutant-killing datasets for numeric columns (patched)...")
    for c in cleaned_constraints:
        if isinstance(c, dict) and c.get('type') in ('gt', 'gte', 'lt', 'lte', 'eq', 'neq'):
            left = c.get('left')
            right = c.get('right')
            col = None
            val = None
            # Try both sides for column and value, and parse value if string
            if isinstance(left, list):
                col = left
                val = try_parse_number(right)
            elif isinstance(right, list):
                col = right
                val = try_parse_number(left)
            # Only proceed if we have a column and a valid number value
            if col is not None and val is not None:
                col_key = '__'.join(col) if isinstance(col, list) else col
                table, column = col[-2], col[-1] if len(col) > 1 else (None, col[-1])
                col_type = None
                if table and column and table in schema_info and column in schema_info[table]:
                    col_type = schema_info[table][column].get('type', '')
                if is_numeric_type(col_type):
                    for mutant_val in [val, val-1, val+1]:
                        if is_float_type(col_type):
                            mutant_val = float(mutant_val)
                        else:
                            mutant_val = int(mutant_val)
                        mutant_assignment = dict(generator.assignment)
                        mutant_assignment[col_key] = mutant_val
                        mutant_assignment = backpropagate_computed_assignments(mutant_assignment, projected_columns, schema_info)
                        print(f"[DEBUG] Mutant assignment for {col_key} = {mutant_val}: {mutant_assignment}")
                        generator_mut = TestDataGenerator(schema_info, mutant_assignment, conn_str, schema=cfg['schema'], projected_columns=projected_columns)
                        print("[DEBUG] table_row_data before insert_to_db (generalized numeric mutant):")
                        for tbl, rows in generator_mut.table_row_data.items():
                            print(f"Table {tbl}: {len(rows)} rows")
                            for row in rows:
                                print(row)
                        generator_mut.insert_to_db()
                else:
                    print(f"[DEBUG] Skipping constraint for {col_key}: not a numeric type ({col_type})")
            else:
                print(f"[DEBUG] Skipping constraint: could not parse numeric value (left={left}, right={right})")













