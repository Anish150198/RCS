import sqlglot
import json
from tree_node import *
import sys

class Tee(object):
    def __init__(self, *files):
        self.files = files
    def write(self, obj):
        for f in self.files:
            f.write(obj)
            f.flush()
    def flush(self):
        for f in self.files:
            f.flush()
sys.stdout = Tee(sys.stdout, open('output.txt', 'a'))
sys.stderr = sys.stdout  # For errors too

class QueryParser:
    """
    Parses SQL using sqlglot, builds AST, collects subqueries, and maps aliases to real tables.
    """
    def __init__(self, sql_file=None, sql=None, dialect='tsql'):
        if sql_file:
            with open(sql_file, 'r') as f:
                self.query = f.read()
        elif sql:
            self.query = sql
        else:
            raise ValueError("Either sql_file or sql string must be provided.")
        self.dialect = dialect
        self.ast = None
        self._parse()
        self.alias_to_table = self._build_alias_map()  # <---- new alias map

    def _parse(self):
        try:
            self.ast = sqlglot.parse_one(self.query, dialect=self.dialect)
        except Exception as e:
            raise RuntimeError(f"Failed to parse SQL: {e}")

    def get_ast(self):
        return self.ast

    def as_dict(self):
        return self.ast.dump() if self.ast else None

    def dump_json(self, outfile='tree.json'):
        tree_json = json.dumps(self.as_dict(), indent=2)
        with open(outfile, 'w') as out_f:
            out_f.write(tree_json)
        print(f"AST written to {outfile}")

    def find_subqueries(self, node=None):
        if node is None:
            node = self.ast
        subqueries = []
        if node.__class__.__name__ == "Subquery":
            subqueries.append(node)
        for child in node.iter_expressions():
            subqueries.extend(self.find_subqueries(child))
        return subqueries

    def _build_alias_map(self):
        """
        Returns a dict mapping alias → base table name (ex: 'i' → 'item', 'ss' → 'store_sales')
        Always prefers the alias used in FROM/JOIN, otherwise maps table to itself.
        """
        alias_to_table = {}
        ast = self.ast

        # Helper to recursively find all FROM and JOIN tables (with/without aliases)
        def collect_from_joins(node):
            # Look for FROM
            if hasattr(node, "args") and "from" in node.args:
                from_ = node.args["from"]
                table_ast = from_.args["this"]
                table_name = _get_base_table_name(table_ast)
                alias = _get_alias(table_ast)
                if alias:
                    alias_to_table[alias] = table_name
                else:
                    alias_to_table[table_name] = table_name
            # Look for JOINS
            joins = node.args.get("joins") if hasattr(node, "args") else None
            if joins:
                for join in joins:
                    table_ast = join.args["this"]
                    table_name = _get_base_table_name(table_ast)
                    alias = _get_alias(table_ast)
                    if alias:
                        alias_to_table[alias] = table_name
                    else:
                        alias_to_table[table_name] = table_name
        def _get_base_table_name(table_ast):
            # Handles nested Table/Identifier wrappers
            t = table_ast
            while hasattr(t, "args") and "this" in t.args:
                t = t.args["this"]
            return str(t)
        def _get_alias(table_ast):
            alias = None
            if hasattr(table_ast, "args") and "alias" in table_ast.args:
                alias_obj = table_ast.args["alias"]
                if alias_obj and hasattr(alias_obj, "args") and "this" in alias_obj.args:
                    at = alias_obj.args["this"]
                    # Sometimes Identifier object, sometimes string
                    if hasattr(at, "args") and "this" in at.args:
                        alias = str(at.args["this"])
                    elif isinstance(at, str):
                        alias = at
            return alias

        collect_from_joins(ast)
        return alias_to_table

    def get_alias_to_table(self):
        """
        Returns alias_to_table dict: alias -> base_table
        Use this mapping everywhere downstream for type/col lookups!
        """
        return self.alias_to_table
    
    def get_alias_to_table(self):
        """
        Returns a dict mapping alias -> real table name for all FROM/JOIN tables.
        (If no alias, the mapping is table_name -> table_name)
        Handles subqueries and complex FROM/JOIN nodes robustly.
        """
        mapping = {}
        ast_dict = self.as_dict()
        def extract_table_alias(table_node):
            # Handles nested Table/Identifier wrappers, subqueries, etc.
            if not isinstance(table_node, dict):
                return None, None
            if table_node.get('class') == 'Table':
                tname = None
                alias = None
                t = table_node.get('args', {}).get('this')
                if isinstance(t, dict) and t.get('class') == 'Identifier':
                    tname = t.get('args', {}).get('this')
                alias_obj = table_node.get('args', {}).get('alias')
                if alias_obj and isinstance(alias_obj, dict):
                    alias_val = alias_obj.get('args', {}).get('this')
                    if isinstance(alias_val, dict):
                        alias = alias_val.get('args', {}).get('this')
                    else:
                        alias = alias_val
                return tname, alias
            # If subquery or other, skip
            return None, None
        # FROM clause
        from_ = ast_dict.get("args", {}).get("from", {})
        if from_:
            table = from_.get("args", {}).get("this")
            tname, alias = extract_table_alias(table)
            if tname:
                if alias:
                    mapping[alias] = tname
                else:
                    mapping[tname] = tname
        # Joins
        for join in ast_dict.get("args", {}).get("joins", []):
            table = join.get("args", {}).get("this")
            tname, alias = extract_table_alias(table)
            if tname:
                if alias:
                    mapping[alias] = tname
                else:
                    mapping[tname] = tname
        # Print if UNION/INTERSECT/EXCEPT present
        set_ops = []
        if ast_dict.get('class', '').upper() in ("UNION", "INTERSECT", "EXCEPT"):
            set_ops.append(ast_dict.get('class', '').upper())
        for k in ast_dict.get('args', {}):
            v = ast_dict['args'][k]
            if isinstance(v, dict) and v.get('class', '').upper() in ("UNION", "INTERSECT", "EXCEPT"):
                set_ops.append(v.get('class', '').upper())
        if set_ops:
            print(f"[DEBUG] Query contains set operations: {set_ops}")
        return mapping


    def build_query_tree(self, node=None):
        if node is None:
            node = self.ast

        node_type = node.__class__.__name__.upper()
        children = []

        operator = None
        if node_type == "JOIN":
            operator = node.args.get("side", "INNER")
        elif node_type in ("SUM", "COUNT", "MAX", "MIN", "AVG"):
            operator = node_type

        if node_type == "SELECT":
            from_ = node.args.get("from")
            if from_:
                children.append(self.build_query_tree(from_))
            joins = node.args.get("joins") or []
            for join in joins:
                children.append(self.build_query_tree(join))
            where = node.args.get("where")
            if where:
                children.append(self.build_query_tree(where))
            group = node.args.get("group")
            if group:
                children.append(self.build_query_tree(group))
            having = node.args.get("having")
            if having:
                children.append(self.build_query_tree(having))
            for expr in node.args.get("expressions", []):
                children.extend(self._extract_subqueries_from_expr(expr))
        elif node_type == "JOIN":
            join_table = node.args.get("this")
            if join_table:
                children.append(self.build_query_tree(join_table))
            on_ = node.args.get("on")
            if on_:
                children.append(self.build_query_tree(on_))
        elif node_type in ("WHERE", "HAVING", "GROUP", "ORDER"):
            for subexpr in node.args.values():
                if isinstance(subexpr, list):
                    for se in subexpr:
                        children.append(self.build_query_tree(se))
                else:
                    children.append(self.build_query_tree(subexpr))
        elif node_type == "SUBQUERY":
            sub_sel = node.args.get("this")
            if sub_sel:
                children.append(self.build_query_tree(sub_sel))
        elif hasattr(node, "args") and isinstance(node.args, dict):
            for k, v in node.args.items():
                if isinstance(v, list):
                    for item in v:
                        if hasattr(item, "args"):
                            children.append(self.build_query_tree(item))
                elif hasattr(v, "args"):
                    children.append(self.build_query_tree(v))

        qt_node = QueryTreeNode(node_type=node_type, children=children, ast_node=node, operator=operator)
        return qt_node

    def _extract_subqueries_from_expr(self, expr):
        nodes = []
        if expr.__class__.__name__.upper() == "SUBQUERY":
            nodes.append(self.build_query_tree(expr))
        if hasattr(expr, "args") and isinstance(expr.args, dict):
            for v in expr.args.values():
                if isinstance(v, list):
                    for item in v:
                        nodes.extend(self._extract_subqueries_from_expr(item))
                elif hasattr(v, "args"):
                    nodes.extend(self._extract_subqueries_from_expr(v))
        return nodes

    def find_subqueries(self, node=None, found=None):
        if found is None:
            found = []
        if node is None:
            node = self.ast
        if node.__class__.__name__.upper() == "SUBQUERY" and node not in found:
            found.append(node)
        if hasattr(node, "args"):
            for v in node.args.values():
                if isinstance(v, list):
                    for child in v:
                        self.find_subqueries(child, found)
                elif hasattr(v, "args"):
                    self.find_subqueries(v, found)
        return found

import json
# Example usage:
if __name__ == "__main__":
    parser = QueryParser(sql_file="query.sql")
    qt_root = parser.build_query_tree()
    print("[DEBUG] QueryTreeNode structure:")
    qt_root.pretty_print()
    print("[DEBUG] QueryTreeNode repr:", qt_root)
    print("[DEBUG] AST as dict:")
    import pprint
    pprint.pprint(parser.as_dict())
    print("[DEBUG] All subqueries:", parser.find_subqueries())
    print("[DEBUG] AST top-level keys:", list(parser.as_dict()['args'].keys()))
    print("[DEBUG] Alias to table:", parser.get_alias_to_table())
    parser.dump_json('tree.json')
