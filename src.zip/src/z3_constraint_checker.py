from z3 import *
import re

def _pick_string_from_like_pattern(pattern):
    result = []
    for c in pattern:
        if c == '%':
            result.append('A')
        elif c == '_':
            result.append('A')
        else:
            result.append(c)
    return ''.join(result)

def _pick_value_from_in(values):
    # Always pick the first, but could randomize or round-robin for mutant testing
    if values:
        return values[0]
    return None

def _pick_value_from_between(low, high):
    # Picks the lower bound, but can randomize as needed
    if isinstance(low, (int, float)) and isinstance(high, (int, float)):
        return low
    if isinstance(low, str) and isinstance(high, str):
        return low
    return low

def _pick_value_from_substring(base_value, start, length):
    # Always create a string long enough, then extract substring
    base = str(base_value) if base_value is not None else 'A' * (start + length - 1)
    return base[start-1:start-1+length]



class Z3ConstraintChecker:
    def __init__(self, constraint_list, schema_info=None, alias_to_table=None):
        self.constraint_list = constraint_list
        self.z3_vars = {}
        self.schema_info = schema_info if schema_info is not None else {}
        self.alias_to_table = alias_to_table if alias_to_table is not None else {}
        self.like_patterns = {}
        self.in_sets = {}
        self.between_ranges = {}
        self.substring_constraints = {}

    def get_col_type(self, var, values_for_in=None):
        # 1. Expression/function case: always treat as str for Z3
        if isinstance(var, str) and (var.lower().startswith("substring") or "(" in var):
            return "str"
        # 2. [table, col] lookup
        if isinstance(var, list) and len(var) == 2:
            table, col = var
            real_table = self.alias_to_table.get(table, table)
            if real_table in self.schema_info and col in self.schema_info[real_table]:
                t = self.schema_info[real_table][col]['type'].lower()
                if any(x in t for x in ['char', 'text', 'string', 'date', 'time']):
                    return "str"
                elif any(x in t for x in ['float', 'real', 'decimal']):
                    return "real"
                else:
                    return "int"
        # 3. If all IN values are string, treat as str
        if values_for_in:
            # If any value cannot be safely converted to int/float, treat as str
            if all(isinstance(v, str) and not v.isdigit() for v in values_for_in):
                return "str"
            if all(isinstance(v, (int, float)) or (isinstance(v, str) and v.isdigit()) for v in values_for_in):
                return "int"
        # 4. If var is string literal (not digit), treat as str
        if isinstance(var, str) and not (var.isdigit() or (var.startswith('-') and var[1:].isdigit())):
            return "str"
        return "int"


    def to_z3_var(self, var, typ_hint="int"):
        if isinstance(var, str) and var.lower().startswith("substring"):
            typ_hint = "str"
        # Column variables (lists) are always Z3 variables
        if isinstance(var, list):
            vname = "__".join([str(x) for x in var if x is not None])
            if vname in self.z3_vars:
                return self.z3_vars[vname]
            if typ_hint == "bool":
                self.z3_vars[vname] = Bool(vname)
            elif typ_hint == "real":
                self.z3_vars[vname] = Real(vname)
            elif typ_hint == "str":
                self.z3_vars[vname] = String(vname)
            else:
                self.z3_vars[vname] = Int(vname)
            return self.z3_vars[vname]
        # Now, literal constants (int, float, str)
        if typ_hint == "int":
            if isinstance(var, int):
                return IntVal(var)
            if isinstance(var, str) and (var.isdigit() or (var.startswith('-') and var[1:].isdigit())):
                return IntVal(int(var))
        if typ_hint == "real":
            try:
                return RealVal(float(var))
            except Exception:
                pass
        if typ_hint == "str":
            if isinstance(var, str):
                return StringVal(var.strip("'\""))
            if isinstance(var, int):
                return StringVal(str(var))
        # Fallback for weird literals (should never reach)
        if isinstance(var, str):
            if "__" in var or "." in var:
                vname = var.replace(".", "__")
                if vname in self.z3_vars:
                    return self.z3_vars[vname]
                if typ_hint == "str":
                    self.z3_vars[vname] = String(vname)
                elif typ_hint == "real":
                    self.z3_vars[vname] = Real(vname)
                else:
                    self.z3_vars[vname] = Int(vname)
                return self.z3_vars[vname]
            return StringVal(var)
        if isinstance(var, float):
            return RealVal(var)
        return str(var)



    def _to_z3_expr(self, e):
        if isinstance(e, ExprRef):
            return e
        if isinstance(e, bool):
            return BoolVal(e)
        if e is None:
            return BoolVal(True)
        return BoolVal(True)

    def to_z3_constraint(self, constraint):
        typ = constraint.get("type")
        # Skip aggregate constraints (COUNT, SUM, etc.) before any Z3 logic
        if (isinstance(constraint.get("left"), dict) and constraint["left"].get("type") == "aggregate") or \
           (isinstance(constraint.get("right"), dict) and constraint["right"].get("type") == "aggregate"):
            return BoolVal(True)
        # Logical connectives
        if typ == "and":
            subexprs = [self.to_z3_constraint(c) for c in (constraint.get("left", []) + constraint.get("right", []))]
            subexprs = [self._to_z3_expr(e) for e in subexprs if e is not None]
            return And(*subexprs) if subexprs else BoolVal(True)
        elif typ == "or":
            subexprs = [self.to_z3_constraint(c) for c in (constraint.get("left", []) + constraint.get("right", []))]
            subexprs = [self._to_z3_expr(e) for e in subexprs if e is not None]
            return Or(*subexprs) if subexprs else BoolVal(True)
        elif typ == "not":
            vals = constraint.get("value", [])
            expr = self.to_z3_constraint(vals[0]) if vals else BoolVal(True)
            return Not(self._to_z3_expr(expr))
        
        elif typ == "like":
            col = constraint["column"]
            pattern = constraint["pattern"]
            col_typ = self.get_col_type(col)
            z3_var = self.to_z3_var(col, typ_hint=col_typ)
            vname = "__".join([str(x) for x in col]) if isinstance(col, list) else str(col)
            self.like_patterns[vname] = pattern
            return BoolVal(True)
        elif typ == "in":
            col = constraint["column"]
            values = constraint["values"]
            vname = "__".join([str(x) for x in col]) if isinstance(col, list) else str(col)
            self.in_sets[vname] = values
            # Standard Z3 constraint for correctness (but assignment always picks the first)
            var = self.to_z3_var(col, typ_hint=self.get_col_type(col, values))
            z3_vals = [self.to_z3_var(v, typ_hint=self.get_col_type(col, values)) for v in values]
            return Or(*[var == v for v in z3_vals])
        elif typ == "between":
            col = constraint["column"]
            low, high = constraint["low"], constraint["high"]
            vname = "__".join([str(x) for x in col]) if isinstance(col, list) else str(col)
            self.between_ranges[vname] = (low, high)
            var = self.to_z3_var(col, typ_hint=self.get_col_type(col))
            return And(var >= self.to_z3_var(low), var <= self.to_z3_var(high))
        elif typ == "in" and isinstance(constraint["column"], str) and constraint["column"].startswith("substring"):
            # Handle substring constraints
            m = re.match(r"substring\(\[(.*?)\],(\d+),(\d+)\)", constraint["column"])
            if m:
                col_table_col, start, length = m.group(1), int(m.group(2)), int(m.group(3))
                base_table, base_col = [x.strip(" '") for x in col_table_col.split(",")]
                substr_var = f"substr__{base_table}__{base_col}"
                self.substring_constraints[substr_var] = (base_table, base_col, start, length, constraint["values"])
            return BoolVal(True)

        # Atomic predicates
        elif typ in ("equality", "eq", "neq", "gt", "gte", "lt", "lte"):
            left = constraint["left"]
            right = constraint["right"]
            left_type = self.get_col_type(left)
            right_type = self.get_col_type(right)
            # If either is string, treat as string
            if left_type == "str" or right_type == "str":
                col_type = "str"
            elif left_type == "real" or right_type == "real":
                col_type = "real"
            else:
                col_type = "int"
            l = self.to_z3_var(left, typ_hint=col_type)
            r = self.to_z3_var(right, typ_hint=col_type) if not isinstance(right, str) or right in self.z3_vars else right
            # --- DEBUG PRINT ---
            print(f"[Z3 DEBUG] Adding constraint: {left} == {right} (Z3 var: {l})")
            try:
                if typ in ("equality", "eq"):
                    return l == r
                elif typ == "neq":
                    return l != r
                elif typ == "gt":
                    return l > r
                elif typ == "gte":
                    return l >= r
                elif typ == "lt":
                    return l < r
                elif typ == "lte":
                    return l <= r
            except Exception as e:
                print(f"\n[EQ ERROR] Z3 type error: {e}")
                print("left:", left, "as", type(l), "=", l)
                print("right:", right, "as", type(r), "=", r)
                print("left_type:", left_type, "right_type:", right_type)
                raise
        # Skip aggregate constraints (COUNT, SUM, etc.)
        elif (isinstance(constraint.get("left"), dict) and constraint["left"].get("type") == "aggregate") or \
             (isinstance(constraint.get("right"), dict) and constraint["right"].get("type") == "aggregate"):
            return BoolVal(True)

        

        # Unsupported/complex/ignored
        elif typ in ("like", "is_null", "is_not_null", "in_subquery", "exists_subquery",
                     "aggregate", "group_by", "order_by", "limit", "primary_key", "foreign_key",
                     "domain", "not_null", "scalar_subquery"):
            return BoolVal(True)
        else:
            return BoolVal(True)

    def build_formula(self):
        return [self.to_z3_constraint(c) for c in self.constraint_list]

    def check_satisfiability(self):
        constraints = self.build_formula()
        s = Solver()
        s.add(*constraints)
        result = s.check()
        return result, s, self.z3_vars

    def get_minimal_assignment(self):
        constraints = self.build_formula()
        s = Solver()
        s.add(*constraints)
        assignment = {}
        if s.check() == sat:
            model = s.model()
            # First assign from model
            for d in model.decls():
                vname = d.name()
                assignment[vname] = model[d]
            # Now postprocess for LIKE
            for vname, pattern in self.like_patterns.items():
                assignment[vname] = _pick_string_from_like_pattern(pattern)
            # Postprocess for IN
            for vname, values in self.in_sets.items():
                assignment[vname] = _pick_value_from_in(values)
            # Postprocess for BETWEEN
            for vname, (low, high) in self.between_ranges.items():
                assignment[vname] = _pick_value_from_between(low, high)
            # Postprocess for SUBSTRING
            for substr_var, (base_table, base_col, start, length, values) in self.substring_constraints.items():
                base_var = f"{base_table}__{base_col}"
                base_val = assignment.get(base_var, None)
                substr_val = _pick_value_from_substring(base_val, start, length)
                assignment[substr_var] = substr_val
            # --- Ensure all not-null and PK columns for every table are present ---
            for table, cols in (self.schema_info or {}).items():
                for col, meta in cols.items():
                    vname = f"{table}__{col}"
                    if (not meta.get('nullable', True) or meta.get('is_pk')) and vname not in assignment:
                        # Fill with default value based on type
                        t = meta.get('type', '').lower()
                        if any(x in t for x in ['char', 'text', 'string', 'date', 'time']):
                            assignment[vname] = 'A'
                        elif any(x in t for x in ['float', 'real', 'decimal']):
                            assignment[vname] = 1.0
                        else:
                            assignment[vname] = 1
            return assignment
        else:
            return None


# ------------- Usage Example -------------

from constraint_extractor import ConstraintExtractor
from query_parser import QueryParser
from config_util import load_config, build_sqlserver_connstr, fetch_schema_column_info, load_pkfk_csv_custom

def ast_to_python(obj):
    if isinstance(obj, (str, int, float, bool)) or obj is None:
        return obj
    elif hasattr(obj, "args"):
        if "this" in obj.args:
            return ast_to_python(obj.args["this"])
        return str(obj)
    elif isinstance(obj, dict):
        return {ast_to_python(k): ast_to_python(v) for k, v in obj.items()}
    elif isinstance(obj, (list, tuple)):
        return [ast_to_python(x) for x in obj]
    return str(obj)

if __name__ == "__main__":
    parser = QueryParser(sql_file="query.sql")
    qt_root = parser.build_query_tree()
    alias_to_table = parser.get_alias_to_table()  # <-- Use your updated parser

    cfg = load_config("config.ini")
    conn_str = build_sqlserver_connstr(cfg)
    schema_info = fetch_schema_column_info(conn_str, db_schema=cfg['schema'])
    pkfk_list = load_pkfk_csv_custom(cfg['pkfk_path'])

    extractor = ConstraintExtractor(qt_root, schema_info, pkfk_list, alias_to_table=alias_to_table)
    constraint_set = extractor.extract_constraints()
    cleaned_constraints = ast_to_python(constraint_set.all())

    z3_checker = Z3ConstraintChecker(
        cleaned_constraints, schema_info, alias_to_table=alias_to_table
    )
    result, solver, z3_vars = z3_checker.check_satisfiability()
    print("SAT Result:", result)
    if result == sat:
        print("Model:")
        for d in solver.model().decls():
            print(" ", d.name(), "=", solver.model()[d])
    else:
        print("UNSAT. Please check debug above.")
    assignment = z3_checker.get_minimal_assignment()
    print("Minimal dataset assignment:", assignment)
