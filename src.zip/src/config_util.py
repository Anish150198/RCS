import os
import pyodbc
import configparser
import csv

def load_config(path="config.ini"):
    config = configparser.ConfigParser()
    config.read(path)
    db_cfg = config['database']
    dbname = db_cfg.get('dbname')
    host = db_cfg.get('host')
    port = db_cfg.get('port')
    user = db_cfg.get('user')
    password = db_cfg.get('password')
    schema = db_cfg.get('schema')
    pkfk_path = config['support']['pkfk']
    if not os.path.exists(pkfk_path) and os.path.exists(os.path.join("src", pkfk_path)):
        pkfk_path = os.path.join("src", pkfk_path)
    return {
        "host": host,
        "port": port,
        "user": user,
        "password": password,
        "dbname": dbname,
        "schema": schema,
        "pkfk_path": pkfk_path,
    }

def build_sqlserver_connstr(cfg):
    return (
        f"DRIVER={{ODBC Driver 17 for SQL Server}};"
        f"SERVER={cfg['host']},{cfg['port']};"
        f"DATABASE={cfg['dbname']};"
        f"UID={cfg['user']};"
        f"PWD={cfg['password']};"
    )



def fetch_schema_column_info(conn_str, db_schema="dbo"):
    """Returns: schema_info = {table: {column: {"type": ..., "nullable": ..., "max_length": ...}}}"""
    schema_info = {}
    with pyodbc.connect(conn_str) as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA=?
        """, db_schema)
        tables = [row[0] for row in cursor.fetchall()]
        for table in tables:
            cursor.execute(f"""
                SELECT COLUMN_NAME, DATA_TYPE, IS_NULLABLE, CHARACTER_MAXIMUM_LENGTH
                FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_SCHEMA=? AND TABLE_NAME=?
            """, db_schema, table)
            schema_info[table] = {}
            for col, typ, nullable, maxlen in cursor.fetchall():
                schema_info[table][col] = {
                    "type": typ, "nullable": nullable == "YES", "max_length": maxlen
                }
    return schema_info





def load_pkfk_csv_custom(pkfk_csv_path):
    pkfk_list = []
    with open(pkfk_csv_path, 'r', newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            if not any(row.values()):
                continue
            pkfk = {
                "table": row.get("TABLE_NAME"),
                "attribute": row.get("ATTRIBUTE_NAME"),
                "is_pk": row.get("IS_PK", "n"),
                "is_fk": row.get("IS_FK", "n"),
                "ref_table": row.get("REFERENCING_TABLE"),
                "ref_attribute": row.get("REFERENCING_ATTRIBUTE"),
            }
            pkfk_list.append(pkfk)
    return pkfk_list