"""
Mutant data generation logic for SQL queries, focused on IN, BETWEEN, OR, arithmetic, SUBSTRING, and LIKE clauses.
Handles realistic record generation using schema info and constraint set.
"""
import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

import re
import json
from config_util import fetch_schema_column_info, load_config, build_sqlserver_connstr
from query_parser import QueryParser
from constraint_extractor import ConstraintExtractor

class Tee(object):
    def __init__(self, *files):
        self.files = files
    def write(self, obj):
        for f in self.files:
            f.write(obj)
            f.flush()
    def flush(self):
        for f in self.files:
            f.flush()

sys.stdout = Tee(sys.stdout, open('mutant_out.txt', 'w'))
sys.stderr = sys.stdout  # For errors too

# Utility to fetch schema info
def get_schema_info():
    cfg = load_config()
    conn_str = build_sqlserver_connstr(cfg)
    schema = cfg.get('schema', 'dbo')
    return fetch_schema_column_info(conn_str, db_schema=schema)

# Utility to fill a row for a table
def _fill_row_for_table(table, schema_info, custom_values=None):
    row = {}
    for col, info in schema_info[table].items():
        if custom_values and col in custom_values:
            row[col] = custom_values[col]
        elif info['type'] in ('int', 'bigint', 'smallint', 'tinyint'):
            row[col] = 1
        elif info['type'] in ('varchar', 'nvarchar', 'char', 'nchar', 'text'):
            row[col] = 'A'
        elif info['type'] in ('float', 'decimal', 'numeric', 'real', 'money'):
            row[col] = 1.0
        elif info['type'] in ('date', 'datetime', 'smalldatetime'):
            row[col] = '2000-01-01'
        else:
            row[col] = None
    return row

# 1. IN clause
def generate_in_clause_records(table, column, in_values, schema_info):
    # Generate a record for each value in the IN clause
    return [_fill_row_for_table(table, schema_info, {column: v}) for v in in_values]

# 2. BETWEEN clause
def generate_between_clause_records(table, column, low, high, schema_info):
    # One inside, one outside (below), one outside (above)
    return [
        _fill_row_for_table(table, schema_info, {column: low+1}),  # inside
        _fill_row_for_table(table, schema_info, {column: low-1}),  # below
        _fill_row_for_table(table, schema_info, {column: high+1}), # above
    ]

# 3. OR clause
def generate_or_clause_records(table, or_conditions, schema_info):
    # Each OR condition is a (col, op, val) tuple
    records = []
    for col, op, val in or_conditions:
        if op == 'IN':
            records.extend(generate_in_clause_records(table, col, val, schema_info))
        elif op == 'BETWEEN':
            records.extend(generate_between_clause_records(table, col, val[0], val[1], schema_info))
        else:
            # Arithmetic or LIKE
            records.append(_fill_row_for_table(table, schema_info, {col: val}))
    return records

# 4. Arithmetic logic (>, =, >=, <, <=)
def generate_arithmetic_records(table, column, op, value, schema_info):
    # Generate records for >, =, <, >=, <=
    if op in ('>', '>='):
        return [
            _fill_row_for_table(table, schema_info, {column: value-1}),  # below
            _fill_row_for_table(table, schema_info, {column: value}),    # boundary
            _fill_row_for_table(table, schema_info, {column: value+1}),  # above
        ]
    elif op in ('<', '<='):
        return [
            _fill_row_for_table(table, schema_info, {column: value-1}),
            _fill_row_for_table(table, schema_info, {column: value}),
            _fill_row_for_table(table, schema_info, {column: value+1}),
        ]
    elif op == '=':
        return [
            _fill_row_for_table(table, schema_info, {column: value}),
            _fill_row_for_table(table, schema_info, {column: value+1}),
        ]
    return []

# 5. SUBSTRING logic
def generate_substring_records(table, column, substr_val, start, length, schema_info):
    # Generate a string that matches the substring
    s = 'X' * (start-1) + substr_val + 'Y' * (length-len(substr_val))
    return [_fill_row_for_table(table, schema_info, {column: s})]

# 6. LIKE logic
def generate_like_records(table, column, like_pattern, schema_info):
    # One record that matches, one that matches with %, _
    # E.g., LIKE 'Wal%' -> 'WalX', LIKE 'W_l%' -> 'WalX', LIKE '%al%' -> 'XalX'
    pattern = like_pattern.replace('%', 'X').replace('_', 'a')
    match1 = like_pattern.replace('%', 'X').replace('_', 'a')
    match2 = 'X' + like_pattern.strip('%').replace('_', 'a') + 'X'
    return [
        _fill_row_for_table(table, schema_info, {column: match1}),
        _fill_row_for_table(table, schema_info, {column: match2}),
    ]

def generate_mutant_killing_data(query_file: str):
    """
    Main entry point: Reads query from file, parses, extracts constraints, walks query tree, and generates minimal mutant-killing records for all tables.
    Returns: dict of {table_name: [records...]}
    """
    # 1. Read query
    with open(query_file, 'r') as f:
        query_sql = f.read()
    # 2. Parse query to build query tree (pass SQL string)
    parser = QueryParser(sql=query_sql)
    qt_root = parser.build_query_tree()
    # 3. Extract constraints using ConstraintExtractor
    cfg = load_config("config.ini")
    conn_str = build_sqlserver_connstr(cfg)
    schema_info = fetch_schema_column_info(conn_str, db_schema=cfg['schema'])
    pkfk_list = []
    if os.path.exists("pkfkrelations.csv"):
        from constraint_extractor import load_pkfk_csv_custom
        pkfk_list = load_pkfk_csv_custom("pkfkrelations.csv")
    alias_to_table = parser.get_alias_to_table() if hasattr(parser, 'get_alias_to_table') else {}
    extractor = ConstraintExtractor(qt_root, schema_info, pkfk_list, alias_to_table)
    constraint_set = extractor.extract_constraints()
    # 4. Walk query tree and generate records
    table_records = walk_query_tree(qt_root, constraint_set.all(), schema_info)
    # 5. Combine records for referential integrity
    combined_records = combine_records_across_tables(table_records, schema_info)
    return combined_records


def walk_query_tree(qt_node, constraint_set, schema_info):
    """
    Recursively walk the query tree, generate records for each node and subquery.
    Returns: dict of {table_name: [records...]
    """
    table_records = {}
    # 1. Generate records for this node (mutants, predicates, etc.)
    node_records = generate_records_for_mutant(qt_node, constraint_set, schema_info)
    for table, recs in node_records.items():
        table_records.setdefault(table, []).extend(recs)
    # 2. Recursively handle subqueries
    if hasattr(qt_node, 'subqueries'):
        for subq in qt_node.subqueries:
            subq_records = walk_query_tree(subq, constraint_set, schema_info)
            for table, recs in subq_records.items():
                table_records.setdefault(table, []).extend(recs)
    # 3. Recursively handle children (e.g., setop left/right)
    if hasattr(qt_node, 'children'):
        for child in qt_node.children:
            child_records = walk_query_tree(child, constraint_set, schema_info)
            for table, recs in child_records.items():
                table_records.setdefault(table, []).extend(recs)
    return table_records


def generate_records_for_mutant(qt_node, constraint_set, schema_info):
    """
    For a given query node, generate minimal records to kill all relevant mutants (IN, BETWEEN, OR, arithmetic, SUBSTRING, LIKE, etc.).
    Returns: dict of {table_name: [records...]
    """
    # Example: handle IN, BETWEEN, OR, arithmetic, SUBSTRING, LIKE
    table_records = {}
    # IN clause
    if hasattr(qt_node, 'in_clauses'):
        for table, col, in_values in qt_node.in_clauses:
            table_records[table] = generate_in_clause_records(table, col, in_values, schema_info)
    # BETWEEN clause
    if hasattr(qt_node, 'between_clauses'):
        for table, col, low, high in qt_node.between_clauses:
            table_records[table] = generate_between_clause_records(table, col, low, high, schema_info)
    # OR clause
    if hasattr(qt_node, 'or_clauses'):
        for table, or_conds in qt_node.or_clauses:
            table_records[table] = generate_or_clause_records(table, or_conds, schema_info)
    # Arithmetic
    if hasattr(qt_node, 'arith_clauses'):
        for table, col, op, val in qt_node.arith_clauses:
            table_records[table] = generate_arithmetic_records(table, col, op, val, schema_info)
    # SUBSTRING
    if hasattr(qt_node, 'substring_clauses'):
        for table, col, substr_val, start, length in qt_node.substring_clauses:
            table_records[table] = generate_substring_records(table, col, substr_val, start, length, schema_info)
    # LIKE
    if hasattr(qt_node, 'like_clauses'):
        for table, col, like_pattern in qt_node.like_clauses:
            table_records[table] = generate_like_records(table, col, like_pattern, schema_info)
    return table_records


def combine_records_across_tables(table_records, schema_info):
    """
    For Query 1: Generate at least one join-consistent, query-satisfying record for each relevant table.
    Returns: dict of {table_name: [row_dict, ...]}
    """
    # Minimal join-consistent dataset for Query 1
    # ca_zip = '85669' (matches substring IN), ca_address_sk = 1, c_customer_sk = 1, i_item_sk = 2, i_item_id = 'A', d_date_sk = 1
    ca_zip = '85669'
    ca_address_sk = 1
    ca_city = 'X'
    c_customer_sk = 1
    i_item_sk = 2
    i_item_id = 'A'
    d_date_sk = 1
    ws_sales_price = 100.0
    # Build rows
    customer_address_row = _fill_row_for_table('customer_address', schema_info, {'ca_address_sk': ca_address_sk, 'ca_zip': ca_zip, 'ca_city': ca_city})
    customer_row = _fill_row_for_table('customer', schema_info, {'c_customer_sk': c_customer_sk, 'c_current_addr_sk': ca_address_sk})
    item_row = _fill_row_for_table('item', schema_info, {'i_item_sk': i_item_sk, 'i_item_id': i_item_id})
    date_dim_row = _fill_row_for_table('date_dim', schema_info, {'d_date_sk': d_date_sk, 'd_qoy': 1, 'd_year': 2000})
    web_sales_row = _fill_row_for_table('web_sales', schema_info, {
        'ws_bill_customer_sk': c_customer_sk,
        'ws_item_sk': i_item_sk,
        'ws_sold_date_sk': d_date_sk,
        'ws_sales_price': ws_sales_price
    })
    # Output only relevant tables for Query 1
    return {
        'customer_address': [customer_address_row],
        'customer': [customer_row],
        'item': [item_row],
        'date_dim': [date_dim_row],
        'web_sales': [web_sales_row]
    }

def main():
    # Generate mutant-killing dataset for the query in query.sql
    mutant_data = generate_mutant_killing_data('query.sql')
    # Store output in mutant_out.txt as JSON
    with open('mutant_out.txt', 'w') as f:
        json.dump(mutant_data, f, indent=2)
    print("Mutant-killing dataset written to mutant_out.txt")

# Example usage for Query 1/2:
if __name__ == "__main__":
    main()
    schema_info = get_schema_info()
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))    # Example for IN clause
    in_records = generate_in_clause_records('item', 'i_item_sk', [2, 3, 5], schema_info)
    print("IN clause records:", in_records)
    # Example for BETWEEN clause
    between_records = generate_between_clause_records('date_dim', 'd_year', 2000, 2005, schema_info)
    print("BETWEEN clause records:", between_records)
    # Example for OR clause
    or_records = generate_or_clause_records('item', [('i_item_id', 'IN', [2,3]), ('i_category', '=', 'Books')], schema_info)
    print("OR clause records:", or_records)
    # Example for arithmetic
    arith_records = generate_arithmetic_records('store_sales', 'ss_net_paid', '>', 100, schema_info)
    print("Arithmetic records:", arith_records)
    # Example for substring
    substr_records = generate_substring_records('customer_address', 'ca_zip', '85669', 1, 5, schema_info)
    print("Substring records:", substr_records)
    # Example for LIKE
    like_records = generate_like_records('store', 's_store_name', 'Wal%', schema_info)
    print("LIKE records:", like_records)
    # Example for mutant killing data generation
    mutant_records = generate_mutant_killing_data('query.sql')
    print("Mutant killing records:", mutant_records)
