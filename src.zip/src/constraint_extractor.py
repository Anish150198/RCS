import csv
from tree_node import *
from query_parser import *
import json
import os
import pyodbc
import configparser
import sys

def load_config(path="config.ini"):
    config = configparser.ConfigParser()
    config.read(path)
    db_cfg = config['database']
    dbname = db_cfg.get('dbname')
    host = db_cfg.get('host')
    port = db_cfg.get('port')
    user = db_cfg.get('user')
    password = db_cfg.get('password')
    schema = db_cfg.get('schema')
    pkfk_path = config['support']['pkfk']
    if not os.path.exists(pkfk_path) and os.path.exists(os.path.join("src", pkfk_path)):
        pkfk_path = os.path.join("src", pkfk_path)
    return {
        "host": host,
        "port": port,
        "user": user,
        "password": password,
        "dbname": dbname,
        "schema": schema,
        "pkfk_path": pkfk_path,
    }

def build_sqlserver_connstr(cfg):
    return (
        f"DRIVER={{ODBC Driver 17 for SQL Server}};"
        f"SERVER={cfg['host']},{cfg['port']};"
        f"DATABASE={cfg['dbname']};"
        f"UID={cfg['user']};"
        f"PWD={cfg['password']};"
    )



def fetch_schema_column_info(conn_str, db_schema="dbo"):
    """Returns: schema_info = {table: {column: {"type": ..., "nullable": ...}}}"""
    schema_info = {}
    with pyodbc.connect(conn_str) as conn:
        cursor = conn.cursor()
        # Fetch all tables in schema
        cursor.execute("""
            SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA=?
        """, db_schema)
        tables = [row[0] for row in cursor.fetchall()]
        for table in tables:
            cursor.execute(f"""
                SELECT COLUMN_NAME, DATA_TYPE, IS_NULLABLE
                FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_SCHEMA=? AND TABLE_NAME=?
            """, db_schema, table)
            schema_info[table] = {}
            for col, typ, nullable in cursor.fetchall():
                schema_info[table][col] = {"type": typ, "nullable": nullable == "YES"}
    return schema_info




def load_pkfk_csv_custom(pkfk_csv_path):
    pkfk_list = []
    with open(pkfk_csv_path, 'r', newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            if not any(row.values()):
                continue
            pkfk = {
                "table": row.get("TABLE_NAME"),
                "attribute": row.get("ATTRIBUTE_NAME"),
                "is_pk": row.get("IS_PK", "n"),
                "is_fk": row.get("IS_FK", "n"),
                "ref_table": row.get("REFERENCING_TABLE"),
                "ref_attribute": row.get("REFERENCING_ATTRIBUTE"),
            }
            pkfk_list.append(pkfk)
    return pkfk_list

def detect_table_for_column(column, schema_info):
    found = []
    for table, cols in schema_info.items():
        if column in cols:
            found.append(table)
    return found[0] if len(found) == 1 else None  # Return None if ambiguous

def ast_to_python(obj):
    if isinstance(obj, (str, int, float, bool)) or obj is None:
        return obj
    elif hasattr(obj, "args"):
        if "this" in obj.args:
            return ast_to_python(obj.args["this"])
        return str(obj)
    elif isinstance(obj, dict):
        return {ast_to_python(k): ast_to_python(v) for k, v in obj.items()}
    elif isinstance(obj, (list, tuple)):
        return [ast_to_python(x) for x in obj]
    return str(obj)

class ConstraintSet:
    def __init__(self):
        self.constraints = []

    def add(self, constraint):
        self.constraints.append(constraint)

    def merge(self, other):
        self.constraints.extend(other.constraints)

    def all(self):
        return self.constraints

    def __repr__(self):
        return f"<ConstraintSet n={len(self.constraints)}>"

class ConstraintExtractor:
    def __init__(self, root_node: QueryTreeNode, schema_info, pkfk_list=None, alias_to_table=None):
        self.root_node = root_node
        self.schema_info = schema_info
        self.pkfk_list = pkfk_list if pkfk_list else []
        self.alias_to_table = alias_to_table if alias_to_table else {}

    def resolve_column(self, ref):
        """
        Convert [alias, col] → [table, col] using self.alias_to_table.
        """
        if isinstance(ref, list) and len(ref) == 2:
            alias, col = ref
            if alias is None:
                return [alias, col]
            table = self.alias_to_table.get(alias, alias)
            return [table, col]
        return ref

    def infer_type(self, table, col):
        # Use schema info if available, else default to int
        if table in self.schema_info and col in self.schema_info[table]:
            t = self.schema_info[table][col]['type'].lower()
            if 'char' in t or 'text' in t or 'string' in t:
                return 'str'
            elif 'float' in t or 'real' in t or 'decimal' in t:
                return 'real'
            else:
                return 'int'
        return 'int'

    def extract_constraints(self, node=None) -> ConstraintSet:
        if node is None:
            node = self.root_node
        cset = ConstraintSet()
        node_type = node.node_type

        if node_type == "SELECT":
            self._extract_aggregation_constraints(node, cset)
            self._extract_projection_constraints(node, cset)
            self._extract_domain_null_constraints(node, cset)
            tables = self._collect_all_tables(node)
            self._extract_pkfk_constraints(tables, cset)
            if node.ast_node and node.ast_node.args.get("order"):
                columns = [self._col_str(e.args["this"]) for e in node.ast_node.args["order"]]
                cset.add({"type": "order_by", "columns": columns})
            if node.ast_node and node.ast_node.args.get("limit"):
                cset.add({"type": "limit", "value": node.ast_node.args["limit"].args["this"]})

        if node_type in ("UNION", "INTERSECT", "EXCEPT"):
            self._extract_setop_constraints(node, cset)

        if node_type == "JOIN":
            cset.merge(self._extract_join_constraints(node))
        if node_type == "WHERE":
            cset.merge(self._extract_where_constraints(node))
        if node_type == "GROUP":
            cset.merge(self._extract_groupby_constraints(node))
        if node_type == "HAVING":
            cset.merge(self._extract_having_constraints(node))
        if node_type == "SUBQUERY":
            cset.merge(self.extract_from_subquery(node))

        for child in node.children:
            cset.merge(self.extract_constraints(child))
        return cset

    # ---- Predicate Extraction with OR/AND/Subquery ----
    def _collect_predicate_constraints(self, expr, cset):
        if expr is None:
            return
        typ = expr.__class__.__name__.upper()
        args = expr.args if hasattr(expr, "args") else {}

        if typ == "AND":
            left_cs, right_cs = ConstraintSet(), ConstraintSet()
            self._collect_predicate_constraints(args.get("this"), left_cs)
            self._collect_predicate_constraints(args.get("expression"), right_cs)
            cset.add({
                "type": "and",
                "left": left_cs.all(),
                "right": right_cs.all()
            })
        elif typ == "OR":
            left_cs, right_cs = ConstraintSet(), ConstraintSet()
            self._collect_predicate_constraints(args.get("this"), left_cs)
            self._collect_predicate_constraints(args.get("expression"), right_cs)
            cset.add({
                "type": "or",
                "left": left_cs.all(),
                "right": right_cs.all()
            })
        elif typ == "NOT":
            inner_cs = ConstraintSet()
            self._collect_predicate_constraints(args.get("this"), inner_cs)
            cset.add({
                "type": "not",
                "value": inner_cs.all()
            })
        elif typ == "EQ":
            left = self._col_or_val(args.get("this"))
            right = self._col_or_val(args.get("expression"))
            left, right = self._type_align(left, right)
            cset.add({"type": "equality", "left": left, "right": right})
        elif typ == "NEQ":
            left = self._col_or_val(args.get("this"))
            right = self._col_or_val(args.get("expression"))
            left, right = self._type_align(left, right)
            cset.add({"type": "neq", "left": left, "right": right})
        elif typ == "IN":
            col = self._col_or_val(args.get("this"))
            if "expressions" in args:
                vals = [self._col_or_val(e) for e in args["expressions"]]
                col, vals = self._type_align(col, vals)
                cset.add({"type": "in", "column": col, "values": vals})
            elif "query" in args and args["query"]:
                cset.add({
                    "type": "in_subquery",
                    "column": col,
                    "subquery": self._subquery_dict(args["query"])
                })
        elif typ == "EXISTS":
            if "this" in args:
                cset.add({
                    "type": "exists_subquery",
                    "subquery": self._subquery_dict(args["this"])
                })
        elif typ == "LIKE":
            cset.add({
                "type": "like",
                "column": self._col_or_val(args.get("this")),
                "pattern": self._col_or_val(args.get("expression"))
            })
        elif typ == "BETWEEN":
            col = self._col_or_val(args.get("this"))
            low = self._col_or_val(args.get("low"))
            high = self._col_or_val(args.get("high"))
            col, low = self._type_align(col, low)
            _, high = self._type_align(col, high)
            cset.add({"type": "between", "column": col, "low": low, "high": high})
        elif typ in ("GTE", "GT", "EQ"):  # handle >=, >, =
            left = self._col_or_val(args.get("this"))
            right = self._col_or_val(args.get("expression"))
            # Special handling for COUNT aggregate in HAVING
            def is_count_agg(node):
                return hasattr(node, "__class__") and node.__class__.__name__.upper() == "COUNT"
            # If left is COUNT aggregate
            if is_count_agg(args.get("this")):
                left = {"type": "aggregate", "agg_func": "COUNT", "column": "*"}
            # If right is COUNT aggregate
            if is_count_agg(args.get("expression")):
                right = {"type": "aggregate", "agg_func": "COUNT", "column": "*"}
            cset.add({"type": typ.lower(), "left": left, "right": right})
        elif typ == "GTE":
            l = self._col_or_val(args.get("this"))
            r = self._col_or_val(args.get("expression"))
            l, r = self._type_align(l, r)
            cset.add({"type": "gte", "left": l, "right": r})
        elif typ == "LT":
            l = self._col_or_val(args.get("this"))
            r = self._col_or_val(args.get("expression"))
            l, r = self._type_align(l, r)
            cset.add({"type": "lt", "left": l, "right": r})
        elif typ == "LTE":
            l = self._col_or_val(args.get("this"))
            r = self._col_or_val(args.get("expression"))
            l, r = self._type_align(l, r)
            cset.add({"type": "lte", "left": l, "right": r})
        elif typ == "IS":
            col = self._col_or_val(args.get("this"))
            value = self._col_or_val(args.get("expression"))
            col, value = self._type_align(col, value)
            cset.add({"type": "is", "column": col, "value": value})
        elif typ == "ISNULL":
            col = self._col_or_val(args.get("this"))
            cset.add({"type": "is_null", "column": col})
        elif typ == "ISNOTNULL":
            col = self._col_or_val(args.get("this"))
            cset.add({"type": "is_not_null", "column": col})
        elif typ == "SUBQUERY":
            cset.add({"type": "subquery", **self._subquery_dict(expr)})
        elif typ == "PAREN":
            self._collect_predicate_constraints(args.get("this"), cset)
        else:
            cset.add({"type": "unhandled", "expr": str(expr)})

    def _col_or_val(self, node):
        if node is None: return None
        typ = node.__class__.__name__.upper()
        if typ == "COLUMN":
            col = node.args.get("this")
            table = node.args.get("table")
            col = ast_to_python(col)
            table = ast_to_python(table)
            if not table and col:
                table = detect_table_for_column(col, self.schema_info)
            return self.resolve_column([table, col])
        elif typ == "LITERAL":
            return ast_to_python(node.args.get("this"))
        elif typ == "IDENTIFIER":
            return ast_to_python(node.args.get("this"))
        elif typ == "SUBSTRING":
            base = self._col_or_val(node.args["this"])
            start = self._col_or_val(node.args["start"])
            length = self._col_or_val(node.args["length"])
            # Always treat as string
            return f"substring({base},{start},{length})"
        else:
            return ast_to_python(node)

    def _type_align(self, col, vals):
        """
        Given a column reference [table, col] and a value (or list), use schema to type-cast values.
        Handles IN, EQ, etc. to make both sides type-consistent.
        """
        # If col is a substring, always treat as string
        if isinstance(col, str) and col.startswith("substring"):
            def to_str(x):
                if isinstance(x, str):
                    return x.strip("'").strip('"')
                return str(x)
            if isinstance(vals, list):
                return col, [to_str(v) for v in vals]
            else:
                return col, to_str(vals)

        # If column is [table, col] and we have schema info, cast vals
        if isinstance(col, list) and len(col) == 2:
            table, column = col
            typ = self.infer_type(table, column)
            def cast(v):
                if v is None: return None
                if typ == "str":
                    return str(v).strip("'").strip('"')
                elif typ == "real":
                    try:
                        return float(v)
                    except Exception:
                        return v
                elif typ == "int":
                    try:
                        return int(v)
                    except Exception:
                        return v
                return v
            if isinstance(vals, list):
                return col, [cast(v) for v in vals]
            else:
                return col, cast(vals)
        return col, vals


    # Helper for subqueries (returns a dict representing the subquery structure)
    def _subquery_dict(self, subq):
        select_exprs = []
        where_preds = []
        sel_node = subq.args["this"] if hasattr(subq, "args") and "this" in subq.args else None
        if sel_node and hasattr(sel_node, "args"):
            for e in sel_node.args.get("expressions", []):
                select_exprs.append(self._col_or_val(e))
            where_node = sel_node.args.get("where")
            if where_node:
                cs = ConstraintSet()
                self._collect_predicate_constraints(where_node.args.get("this"), cs)
                where_preds = cs.all()
        return {"select_exprs": select_exprs, "where": where_preds}


    def _extract_domain_null_constraints(self, node, cset):
        columns = self._collect_all_columns(node)
        for table, col in columns:
            if table in self.schema_info and col in self.schema_info[table]:
                info = self.schema_info[table][col]
                cset.add({"type": "domain", "table": table, "column": col, "datatype": info["type"]})
                if not info["nullable"]:
                    cset.add({"type": "not_null", "table": table, "column": col})

    def _collect_all_columns(self, node):
        columns = set()
        if hasattr(node, "ast_node") and node.ast_node:
            ast = node.ast_node
            if ast.__class__.__name__.upper() == "COLUMN":
                col = ast.args.get("this").args["this"] if ast.args.get("this") else None
                table = ast.args.get("table").args["this"] if ast.args.get("table") else None
                if not table and col:
                    table = detect_table_for_column(col, self.schema_info)
                columns.add(tuple(self.resolve_column([table, col])))
            for v in getattr(ast, "args", {}).values():
                if isinstance(v, list):
                    for child in v:
                        columns |= self._collect_all_columns(QueryTreeNode(child.__class__.__name__.upper(), ast_node=child))
                elif hasattr(v, "args"):
                    columns |= self._collect_all_columns(QueryTreeNode(v.__class__.__name__.upper(), ast_node=v))
        for child in node.children:
            columns |= self._collect_all_columns(child)
        return columns

    # ---- PK/FK Extraction ----
    def _extract_pkfk_constraints(self, tables, cset):
        for pkfk in self.pkfk_list:
            table = pkfk["table"]
            attr = pkfk["attribute"]
            if table in tables:
                if pkfk["is_pk"] == "y":
                    cset.add({"type": "primary_key", "table": table, "column": attr})
                if pkfk["is_fk"] == "y":
                    cset.add({
                        "type": "foreign_key",
                        "table": table,
                        "column": attr,
                        "ref_table": pkfk["ref_table"],
                        "ref_column": pkfk["ref_attribute"]
                    })

    def _collect_all_tables(self, node):
        tables = set()
        if hasattr(node, "ast_node") and node.ast_node:
            ast = node.ast_node
            if ast.__class__.__name__.upper() == "TABLE":
                tname = ast.args.get("this").args["this"]
                tables.add(tname)
            for v in getattr(ast, "args", {}).values():
                if isinstance(v, list):
                    for child in v:
                        tables |= self._collect_all_tables(QueryTreeNode(child.__class__.__name__.upper(), ast_node=child))
                elif hasattr(v, "args"):
                    tables |= self._collect_all_tables(QueryTreeNode(v.__class__.__name__.upper(), ast_node=v))
        for child in node.children:
            tables |= self._collect_all_tables(child)
        return tables

    # ---- Other utilities (aggregates, projection, setop, group/having/joins) ----
    def _extract_aggregation_constraints(self, select_node, cset):
        ast_node = select_node.ast_node
        if ast_node:
            for expr in ast_node.args.get("expressions", []):
                agg_type = expr.__class__.__name__.upper()
                if agg_type in ("SUM", "COUNT", "AVG", "MAX", "MIN"):
                    col = self._col_or_val(expr.args.get("this"))
                    alias = expr.args.get("alias").args["this"] if expr.args.get("alias") else None
                    cset.add({
                        "type": "aggregate",
                        "agg_func": agg_type,
                        "column": col,
                        "alias": alias
                    })
                elif agg_type == "ALIAS":
                    inner_expr = expr.args.get("this")
                    inner_type = inner_expr.__class__.__name__.upper()
                    alias = expr.args.get("alias").args["this"]
                    if inner_type == "SUBQUERY":
                        # SCALAR SUBQUERY HANDLING:
                        subq_node = inner_expr.args["this"]
                        scalar_subquery_info = self._extract_scalar_subquery(subq_node, alias)
                        cset.add(scalar_subquery_info)
                    elif inner_type in ("SUM", "COUNT", "AVG", "MAX", "MIN"):
                        col = self._col_or_val(inner_expr.args.get("this"))
                        cset.add({
                            "type": "aggregate",
                            "agg_func": inner_type,
                            "column": col,
                            "alias": alias
                        })
                elif agg_type == "SUBQUERY":
                    # Direct subquery in select (rare but possible)
                    subq_node = expr.args["this"]
                    scalar_subquery_info = self._extract_scalar_subquery(subq_node, None)
                    cset.add(scalar_subquery_info)


    def _extract_scalar_subquery(self, subq_ast, output_alias):
        # subq_ast: sqlglot AST for the subquery's SELECT
        # output_alias: name for this column in the outer query
        select_exprs = []
        from_tables = []
        where_preds = []
        correlation_vars = set()

        # --- Extract SELECT expressions ---
        for expr in subq_ast.args.get("expressions", []):
            # Handles e.g. COUNT(*), SUM(col), etc.
            if hasattr(expr, "args"):
                agg_type = expr.__class__.__name__.upper()
                if agg_type in ("SUM", "COUNT", "AVG", "MAX", "MIN"):
                    select_exprs.append({
                        "type": "aggregate",
                        "agg_func": agg_type,
                        "column": ast_to_python(self._col_or_val(expr.args.get("this")))
                    })
                else:
                    select_exprs.append(ast_to_python(self._col_or_val(expr)))
            else:
                select_exprs.append(ast_to_python(expr))

        # --- Extract FROM tables ---
        from_ast = subq_ast.args.get("from")
        if from_ast:
            if isinstance(from_ast, list):
                for t in from_ast:
                    table_name, alias = self._extract_table_alias(t)
                    from_tables.append([table_name, alias])
            else:
                table_name, alias = self._extract_table_alias(from_ast)
                from_tables.append([table_name, alias])

        # --- Extract WHERE predicate constraints ---
        where_node = subq_ast.args.get("where")
        if where_node:
            cs = ConstraintSet()
            self._collect_predicate_constraints(where_node.args.get("this"), cs)
            where_preds = cs.all()
            # --- Find any correlated variables (outer table references) ---
            for c in where_preds:
                for side in ("left", "right", "column"):
                    val = c.get(side)
                    if isinstance(val, list) and val[0] and val[0] not in [tbl[0] for tbl in from_tables]:
                        correlation_vars.add(tuple(val))  # (table, col)

        # Compose final node:
        return {
            "type": "scalar_subquery",
            "output_alias": output_alias,
            "select_exprs": select_exprs,
            "from": from_tables,
            "where": where_preds,
            "correlation_vars": list(correlation_vars)
        }

    def _extract_table_alias(self, table_ast):
        # Returns (table_name, alias or None)
        table_name = None
        alias = None
        if table_ast and hasattr(table_ast, "args"):
            tname = table_ast.args.get("this")
            if hasattr(tname, "args") and "this" in tname.args:
                table_name = tname.args["this"]
            if "alias" in table_ast.args and table_ast.args["alias"]:
                alias_obj = table_ast.args["alias"]
                if hasattr(alias_obj, "args") and "this" in alias_obj.args:
                    alias = alias_obj.args["this"]
        return table_name, alias


    def _extract_projection_constraints(self, select_node, cset):
        ast_node = select_node.ast_node
        if ast_node and getattr(ast_node, "args", {}):
            if ast_node.args.get("distinct", False):
                cset.add({"type": "distinct"})

    def _extract_setop_constraints(self, node, cset):
        # Robustly extract constraints for set operations (UNION, INTERSECT, EXCEPT)
        if node.node_type in ("UNION", "INTERSECT", "EXCEPT"):
            left_constraints = []
            right_constraints = []
            if node.children and len(node.children) >= 2:
                left_constraints = self.extract_constraints(node.children[0]).all()
                right_constraints = self.extract_constraints(node.children[1]).all()
            cset.add({
                "type": "setop",
                "operation": node.node_type,
                "left": left_constraints,
                "right": right_constraints
            })

    def _extract_join_constraints(self, join_node):
        cset = ConstraintSet()
        if hasattr(join_node, "ast_node") and join_node.ast_node:
            join_args = join_node.ast_node.args
            on_clause = join_args.get("on")
            if on_clause:
                self._collect_predicate_constraints(on_clause, cset)
        return cset

    def _extract_where_constraints(self, where_node):
        cset = ConstraintSet()
        if hasattr(where_node, "ast_node") and where_node.ast_node:
            where_expr = where_node.ast_node.args.get("this")
            self._collect_predicate_constraints(where_expr, cset)
        return cset

    def _extract_groupby_constraints(self, groupby_node):
        cset = ConstraintSet()
        if hasattr(groupby_node, "ast_node") and groupby_node.ast_node:
            for expr in groupby_node.ast_node.args.get("expressions", []):
                col = self._col_or_val(expr)
                cset.add({"type": "group_by", "column": col})
        return cset

    def _extract_having_constraints(self, having_node):
        cset = ConstraintSet()
        if hasattr(having_node, "ast_node") and having_node.ast_node:
            print("[DEBUG] HAVING ast_node:", having_node.ast_node)
            print("[DEBUG] HAVING ast_node.args:", getattr(having_node.ast_node, 'args', {}))
            self._collect_predicate_constraints(having_node.ast_node.args.get("this"), cset)
        return cset

    def extract_from_subquery(self, subquery_node):
        if subquery_node.children:
            return self.extract_constraints(subquery_node.children[0])
        return ConstraintSet()
    
    

    
    def _col_str(self, col_node):
        # Returns (table, column) as tuple, always, or (None, col) if no table.
        if hasattr(col_node, "args"):
            col = None
            table = None
            if "this" in col_node.args:
                if hasattr(col_node.args["this"], "args") and "this" in col_node.args["this"].args:
                    col = col_node.args["this"].args["this"]
                elif isinstance(col_node.args["this"], str):
                    col = col_node.args["this"]
            if "table" in col_node.args and col_node.args["table"]:
                if hasattr(col_node.args["table"], "args") and "this" in col_node.args["table"].args:
                    table = col_node.args["table"].args["this"]
            return (table, col)
        return (None, str(col_node))
    

    def get_projected_columns(self):
        """
        Returns a dict {table: set(cols)} including:
        - All SELECTed columns (as-is, or inside expressions/aggregates)
        - All GROUP BY columns
        - All ORDER BY columns
        - All columns used as arguments to aggregates, subqueries, or expressions in SELECT
        """
        projected = {}  # {table: set([col, ...])}
        alias_to_table = getattr(self, 'alias_to_table', {})

        def _add_col(ref):
            if isinstance(ref, list) and len(ref) == 2:
                table, cname = ref
                # Resolve alias to real table name
                real_table = alias_to_table.get(table, table)
                if real_table and cname:
                    projected.setdefault(real_table, set()).add(cname)
                elif cname:
                    projected.setdefault(None, set()).add(cname)
            elif isinstance(ref, str):
                for table, cols in self.schema_info.items():
                    if ref in cols:
                        projected.setdefault(table, set()).add(ref)
                        break

        def _extract_cols_from_expr(expr):
            cols = []
            if expr is None:
                return cols
            typ = expr.__class__.__name__.upper()
            if typ == "COLUMN":
                table = expr.args.get("table")
                col = expr.args.get("this")
                table_val = None
                if table:
                    table_val = table.args["this"] if hasattr(table, "args") and "this" in table.args else None
                col_val = col.args["this"] if hasattr(col, "args") and "this" in col.args else col
                cols.append([table_val, col_val])
            elif typ in ("SUM", "AVG", "MAX", "MIN", "COUNT"):
                cols += _extract_cols_from_expr(expr.args.get("this"))
            elif typ == "ALIAS":
                cols += _extract_cols_from_expr(expr.args.get("this"))
            elif typ == "SUBSTRING":
                cols += _extract_cols_from_expr(expr.args.get("this"))
            elif typ == "BINARYOP":
                cols += _extract_cols_from_expr(expr.args.get("left"))
                cols += _extract_cols_from_expr(expr.args.get("right"))
            elif typ == "CASE":
                for val in expr.args.values():
                    if isinstance(val, list):
                        for v in val:
                            cols += _extract_cols_from_expr(v)
                    else:
                        cols += _extract_cols_from_expr(val)
            elif typ == "LITERAL":
                pass
            elif typ == "IDENTIFIER":
                pass
            elif typ == "SUBQUERY":
                sub_sel = expr.args.get("this")
                if sub_sel and hasattr(sub_sel, "args"):
                    for subexpr in sub_sel.args.get("expressions", []):
                        cols += _extract_cols_from_expr(subexpr)
            elif hasattr(expr, "args"):
                for v in expr.args.values():
                    if isinstance(v, list):
                        for sub in v:
                            cols += _extract_cols_from_expr(sub)
                    else:
                        cols += _extract_cols_from_expr(v)
            return cols

        ast_node = self.root_node.ast_node
        if ast_node:
            # SELECT clause
            for expr in ast_node.args.get("expressions", []):
                for tbl, col in _extract_cols_from_expr(expr):
                    _add_col([tbl, col])
            # GROUP BY clause
            if "group" in ast_node.args and ast_node.args["group"]:
                for expr in ast_node.args["group"].args.get("expressions", []):
                    for tbl, col in _extract_cols_from_expr(expr):
                        _add_col([tbl, col])
            # ORDER BY clause
            if "order" in ast_node.args and ast_node.args["order"]:
                for expr in ast_node.args["order"]:
                    col_expr = expr.args["this"] if hasattr(expr, "args") and "this" in expr.args else expr
                    for tbl, col in _extract_cols_from_expr(col_expr):
                        _add_col([tbl, col])
        # --- Fix: resolve None-table columns by searching schema_info for a unique match ---
        if None in projected:
            for col in list(projected[None]):
                matches = [t for t, cols in self.schema_info.items() if col in cols]
                if len(matches) == 1:
                    projected.setdefault(matches[0], set()).add(col)
            del projected[None]
        return projected



# ---------- Example usage ----------
if __name__ == "__main__":
    import json
    from pprint import pprint

    parser = QueryParser(sql_file="query.sql")
    alias_to_table = parser.get_alias_to_table()
    qt_root = parser.build_query_tree()
    cfg = load_config("config.ini")
    conn_str = build_sqlserver_connstr(cfg)
    schema_info = fetch_schema_column_info(conn_str, db_schema=cfg['schema'])
    pkfk_list = load_pkfk_csv_custom("pkfkrelations.csv")

    extractor = ConstraintExtractor(qt_root, schema_info, pkfk_list, alias_to_table)
    constraint_set = extractor.extract_constraints()
    
    with open('constraint_set.txt', 'w') as f:
        cleaned_constraints = ast_to_python(constraint_set.all())
        f.write(json.dumps(cleaned_constraints, indent=2))
    #print(json.dumps(cleaned_constraints, indent=2))

class Tee(object):
    def __init__(self, *files):
        self.files = files
    def write(self, obj):
        for f in self.files:
            f.write(obj)
            f.flush()
    def flush(self):
        for f in self.files:
            f.flush()
sys.stdout = Tee(sys.stdout, open('output.txt', 'a'))
sys.stderr = sys.stdout  # For errors too