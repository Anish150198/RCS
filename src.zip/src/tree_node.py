


class QueryTreeNode:
    def __init__(self, node_type, children=None, ast_node=None, operator=None):
        self.node_type = node_type            # e.g., 'SELECT', 'JOIN', 'AGGREGATE', 'SUBQUERY'
        self.children = children or []        # List[QueryTreeNode]
        self.ast_node = ast_node              # Reference to the raw AST node for future use
        self.operator = operator              # e.g., for 'JOIN', could be 'INNER', 'LEFT', etc.
        self.constraints = None               # ConstraintSet (to be filled later)
        self.result_table = None              # To be populated during result table construction
        self.schema_info = None
        self.subquery_nodes = []              # Populated during subquery search

    def add_child(self, child):
        self.children.append(child)

    def __repr__(self):
        return f"<QueryTreeNode type={self.node_type} children={len(self.children)}>"
    
    def pretty_print(self, level=0):
        indent = "  " * level
        op_str = f" [{self.operator}]" if self.operator else ""
        print(f"{indent}{self.node_type}{op_str}")
        for child in self.children:
            child.pretty_print(level + 1)
